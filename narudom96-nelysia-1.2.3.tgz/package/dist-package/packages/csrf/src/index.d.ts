import type { Context, NelysiaPlugin } from "../../core/src/index.ts";
export interface CsrfOptions {
    cookieName?: string;
    headerName?: string;
    safeMethods?: readonly string[];
    exclude?(context: Context): boolean | Promise<boolean>;
}
export interface CsrfContext {
    csrfToken(): string;
}
export type CsrfPlugin = NelysiaPlugin<CsrfContext>;
export declare function csrf(options?: CsrfOptions): CsrfPlugin;
//# sourceMappingURL=index.d.ts.map