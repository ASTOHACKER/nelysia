import { type IncomingMessage, type ServerResponse } from "node:http";
import { type Nelysia } from "../../core/src/app.ts";
export declare function createNodeServer(app: Nelysia<any, any, any>): import("http").Server<typeof IncomingMessage, typeof ServerResponse>;
//# sourceMappingURL=server.d.ts.map