import type { Context, NelysiaPlugin, ResponseData } from "../../core/src/index.ts";
export interface CacheStore {
    get(key: string): ResponseData | undefined | Promise<ResponseData | undefined>;
    set(key: string, value: ResponseData, ttlMs: number): void | Promise<void>;
    delete?(key: string): void | Promise<void>;
}
export interface CacheOptions {
    ttlMs?: number;
    maxEntries?: number;
    key?(context: Context): string;
    store?: CacheStore;
}
export declare function memoryCacheStore(maxEntries?: number): CacheStore;
export type CachePlugin = NelysiaPlugin;
export declare function cache(options?: CacheOptions): CachePlugin;
//# sourceMappingURL=index.d.ts.map