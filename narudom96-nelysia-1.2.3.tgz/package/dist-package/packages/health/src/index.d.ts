import type { NelysiaPlugin } from "../../core/src/index.ts";
export type HealthCheck = () => boolean | string | Record<string, unknown> | Promise<boolean | string | Record<string, unknown>>;
export interface HealthOptions {
    path?: string;
    readinessPath?: string;
    checks?: Record<string, HealthCheck>;
    readiness?(): boolean | Promise<boolean>;
    exposeErrors?: boolean;
}
export interface HealthStatus {
    status: "ok" | "degraded";
    checks: Record<string, unknown>;
}
export type HealthPlugin = NelysiaPlugin;
export declare function health(options?: HealthOptions): HealthPlugin;
//# sourceMappingURL=index.d.ts.map