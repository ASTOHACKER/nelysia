export function health(options = {}) {
    const path = options.path ?? "/health";
    const readinessPath = options.readinessPath ?? "/ready";
    if (!path.startsWith("/") || !readinessPath.startsWith("/"))
        throw new Error("health paths must start with /");
    return ((app) => {
        app.get(path, async ({ response }) => runChecks(options.checks, options.exposeErrors));
        app.get(readinessPath, async ({ response }) => {
            const ready = await options.readiness?.() ?? true;
            const status = await runChecks(options.checks, options.exposeErrors);
            return ready && status.status === "ok" ? status : response(503, { status: "degraded", checks: { ...status.checks, ...(ready ? {} : { readiness: false }) } });
        });
        return app;
    });
}
async function runChecks(checks, exposeErrors = false) {
    const result = {};
    let healthy = true;
    for (const [name, check] of Object.entries(checks ?? {})) {
        try {
            const value = await check();
            result[name] = value;
            if (value === false || (typeof value === "object" && value !== null && "ok" in value && value.ok === false))
                healthy = false;
        }
        catch (error) {
            healthy = false;
            result[name] = exposeErrors ? { ok: false, error: error instanceof Error ? error.message : String(error) } : { ok: false };
        }
    }
    return { status: healthy ? "ok" : "degraded", checks: result };
}
//# sourceMappingURL=index.js.map