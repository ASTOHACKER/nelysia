function base64UrlEncode(bytes) {
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
function base64UrlDecode(str) {
    if (!/^[A-Za-z0-9_-]*$/.test(str))
        throw new Error("invalid base64url characters");
    if (str.length % 4 === 1)
        throw new Error("invalid base64url length");
    let base64 = str.replace(/-/g, "+").replace(/_/g, "/");
    while (base64.length % 4) {
        base64 += "=";
    }
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }
    // Reject alternate encodings with non-zero unused padding bits. This keeps
    // signed input canonical and avoids accepting malformed segment aliases.
    if (base64UrlEncode(bytes) !== str)
        throw new Error("non-canonical base64url segment");
    return bytes;
}
export async function importHmacKey(secret) {
    const enc = new TextEncoder();
    return crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}
export async function signJwt(payload, keyOrSecret, options) {
    const key = typeof keyOrSecret === "string" ? await importHmacKey(keyOrSecret) : keyOrSecret;
    const enc = new TextEncoder();
    const header = { alg: "HS256", typ: "JWT" };
    const now = Math.floor(Date.now() / 1000);
    const fullPayload = { iat: now, ...payload };
    if (options?.expiresIn !== undefined && fullPayload.exp === undefined) {
        fullPayload.exp = now + options.expiresIn;
    }
    const encodedHeader = base64UrlEncode(enc.encode(JSON.stringify(header)));
    const encodedPayload = base64UrlEncode(enc.encode(JSON.stringify(fullPayload)));
    const data = `${encodedHeader}.${encodedPayload}`;
    const signature = await crypto.subtle.sign("HMAC", key, enc.encode(data));
    const encodedSignature = base64UrlEncode(new Uint8Array(signature));
    return `${data}.${encodedSignature}`;
}
function decodeBase64UrlJson(value) {
    if (value.length === 0 || !/^[A-Za-z0-9_-]+$/.test(value))
        throw new Error("invalid base64url segment");
    const decoded = new TextDecoder("utf-8", { fatal: true }).decode(base64UrlDecode(value));
    return JSON.parse(decoded);
}
function audienceMatches(actual, expected) {
    if (actual !== undefined && typeof actual !== "string" && !(Array.isArray(actual) && actual.every((value) => typeof value === "string")))
        return false;
    const values = Array.isArray(actual) ? actual : typeof actual === "string" ? [actual] : [];
    const expectedValues = Array.isArray(expected) ? expected : [expected];
    return values.some((value) => expectedValues.includes(value));
}
export async function verifyJwt(token, keyOrSecret, options = {}) {
    const parts = token.split(".");
    if (parts.length !== 3 || parts.some((part) => part.length === 0)) {
        return { valid: false, reason: "malformed" };
    }
    const [encodedHeader, encodedPayload, encodedSignature] = parts;
    try {
        const header = decodeBase64UrlJson(encodedHeader);
        if (header.alg !== "HS256")
            return { valid: false, reason: "invalid" };
        const key = typeof keyOrSecret === "string" ? await importHmacKey(keyOrSecret) : keyOrSecret;
        const enc = new TextEncoder();
        const data = `${encodedHeader}.${encodedPayload}`;
        if (!/^[A-Za-z0-9_-]+$/.test(encodedSignature))
            return { valid: false, reason: "malformed" };
        const signature = base64UrlDecode(encodedSignature);
        const isValid = await crypto.subtle.verify("HMAC", key, signature, enc.encode(data));
        if (!isValid)
            return { valid: false, reason: "invalid" };
        const payload = decodeBase64UrlJson(encodedPayload);
        if (typeof payload !== "object" || payload === null || Array.isArray(payload))
            return { valid: false, reason: "malformed" };
        const claims = payload;
        if (claims.iss !== undefined && typeof claims.iss !== "string")
            return { valid: false, payload, reason: "invalid" };
        if (claims.aud !== undefined && typeof claims.aud !== "string" && !(Array.isArray(claims.aud) && claims.aud.every((value) => typeof value === "string"))) {
            return { valid: false, payload, reason: "invalid" };
        }
        if (claims.iat !== undefined && (typeof claims.iat !== "number" || !Number.isFinite(claims.iat))) {
            return { valid: false, payload, reason: "invalid" };
        }
        if (options.issuer !== undefined && claims.iss !== options.issuer) {
            return { valid: false, payload, reason: "invalid" };
        }
        if (options.audience !== undefined && !audienceMatches(claims.aud, options.audience)) {
            return { valid: false, payload, reason: "invalid" };
        }
        if (claims.exp !== undefined) {
            if (typeof claims.exp !== "number" || !Number.isFinite(claims.exp))
                return { valid: false, payload, reason: "invalid" };
            const now = Math.floor(Date.now() / 1000);
            if (now >= claims.exp) {
                return { valid: false, payload, reason: "expired" };
            }
        }
        if (claims.nbf !== undefined) {
            if (typeof claims.nbf !== "number" || !Number.isFinite(claims.nbf))
                return { valid: false, payload, reason: "invalid" };
            const now = Math.floor(Date.now() / 1000);
            if (now < claims.nbf) {
                return { valid: false, payload, reason: "invalid" };
            }
        }
        return { valid: true, payload };
    }
    catch {
        return { valid: false, reason: "malformed" };
    }
}
export function jwt(options) {
    if (typeof options.secret !== "string" || options.secret.length === 0)
        throw new Error("jwt secret must not be empty");
    if (options.expiresIn !== undefined && (!Number.isFinite(options.expiresIn) || options.expiresIn <= 0))
        throw new Error("jwt expiresIn must be positive");
    const headerName = (options.headerName ?? "authorization").toLowerCase();
    const keyPromise = importHmacKey(options.secret);
    const verifyOptions = { issuer: options.issuer, audience: options.audience };
    const pluginInstance = {
        async sign(payload, signOptions) {
            const key = await keyPromise;
            return signJwt(payload, key, { expiresIn: signOptions?.expiresIn ?? options.expiresIn });
        },
        async verify(token, verifyOverrides) {
            const key = await keyPromise;
            return verifyJwt(token, key, verifyOverrides ?? verifyOptions);
        }
    };
    return ((app) => {
        // Attach jwt instance to app
        ;
        app[options.name ?? "jwt"] = pluginInstance;
        app.decorate("jwt", pluginInstance, { enumerable: false, lazy: true });
        // Register before-hook specifically for routes declared with auth: "jwt" or auth: true
        const authHook = async (context) => {
            const authHeader = context.headers.get(headerName);
            if (!authHeader || !authHeader.startsWith("Bearer ")) {
                if (isOptionalAuth(context))
                    return;
                return context.response(401, {
                    error: "Unauthorized",
                    message: "Missing or invalid authorization header"
                });
            }
            const token = authHeader.slice(7).trim();
            const key = await keyPromise;
            const verification = await verifyJwt(token, key, verifyOptions);
            if (!verification.valid) {
                const message = verification.reason === "expired" ? "Token expired" : "Invalid token";
                return context.response(401, {
                    error: "Unauthorized",
                    message
                });
            }
            context.auth = verification.payload;
        };
        // Register a route-scoped guard instead of wrapping every protected handler.
        app.registerAuthStrategy("jwt", { guard: authHook });
        return app;
    });
}
function isOptionalAuth(context) {
    const auth = context.route?.auth;
    return typeof auth === "object" && auth !== null && auth.optional === true;
}
//# sourceMappingURL=index.js.map