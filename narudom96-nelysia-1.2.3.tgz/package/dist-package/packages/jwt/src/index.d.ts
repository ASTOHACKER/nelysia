import type { NelysiaPlugin } from "../../core/src/index.ts";
declare module "../../core/src/types.ts" {
    interface AuthStrategyRegistry {
        jwt: JwtPayload;
    }
}
export interface JwtOptions<Claims extends JwtPayload = JwtPayload> {
    secret: string;
    name?: string;
    alg?: "HS256";
    expiresIn?: number;
    headerName?: string;
    issuer?: string;
    audience?: string | string[];
}
export interface JwtPayload {
    [key: string]: unknown;
    sub?: string;
    iss?: string;
    aud?: string | string[];
    exp?: number;
    nbf?: number;
    iat?: number;
}
export interface JwtContext<Claims extends JwtPayload = JwtPayload> {
    jwt: JwtPluginInstance<Claims>;
    auth?: Claims;
}
export declare function importHmacKey(secret: string): Promise<CryptoKey>;
export declare function signJwt(payload: JwtPayload, keyOrSecret: CryptoKey | string, options?: {
    expiresIn?: number;
}): Promise<string>;
export interface JwtVerifyOptions {
    issuer?: string;
    audience?: string | string[];
}
export declare function verifyJwt<T extends JwtPayload = JwtPayload>(token: string, keyOrSecret: CryptoKey | string, options?: JwtVerifyOptions): Promise<{
    valid: boolean;
    payload?: T;
    reason?: "invalid" | "expired" | "malformed";
}>;
export interface JwtPluginInstance<Claims extends JwtPayload = JwtPayload> {
    sign(payload: Claims, options?: {
        expiresIn?: number;
    }): Promise<string>;
    verify<T extends Claims = Claims>(token: string, options?: JwtVerifyOptions): Promise<{
        valid: boolean;
        payload?: T;
        reason?: "invalid" | "expired" | "malformed";
    }>;
}
export type JwtPlugin<Claims extends JwtPayload = JwtPayload> = NelysiaPlugin<JwtContext<Claims>>;
export declare function jwt<Claims extends JwtPayload = JwtPayload>(options: JwtOptions<Claims>): JwtPlugin<Claims>;
//# sourceMappingURL=index.d.ts.map