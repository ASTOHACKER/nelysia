import type { NelysiaPlugin } from "../../core/src/index.ts";
declare module "../../core/src/types.ts" {
    interface AuthStrategyRegistry {
        session: unknown;
    }
}
export interface SessionStore<Value = unknown> {
    get(id: string): Value | undefined | Promise<Value | undefined>;
    set(id: string, value: Value, ttlMs?: number): void | Promise<void>;
    delete(id: string): void | Promise<void>;
}
export interface SessionOptions<Value = unknown> {
    cookieName?: string;
    ttlSeconds?: number;
    store?: SessionStore<Value>;
    generateId?(): string;
}
export interface SessionApi<Value = unknown> {
    id?: string;
    get(): Promise<Value | undefined>;
    set(value: Value): Promise<string>;
    destroy(): Promise<void>;
}
export interface SessionContext<Value = unknown> {
    session: SessionApi<Value>;
    auth?: Value;
}
export declare function memorySessionStore<Value = unknown>(): SessionStore<Value>;
export type SessionPlugin<Value = unknown> = NelysiaPlugin<SessionContext<Value>>;
export declare function session<Value = unknown>(options?: SessionOptions<Value>): SessionPlugin<Value>;
//# sourceMappingURL=index.d.ts.map