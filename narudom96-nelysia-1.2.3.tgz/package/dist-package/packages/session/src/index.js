export function memorySessionStore() {
    const values = new Map();
    return {
        get(id) {
            const entry = values.get(id);
            if (entry?.expiresAt !== undefined && entry.expiresAt <= Date.now()) {
                values.delete(id);
                return undefined;
            }
            return entry?.value;
        },
        set(id, value, ttlMs) {
            values.set(id, { value, ...(ttlMs === undefined ? {} : { expiresAt: Date.now() + ttlMs }) });
        },
        delete(id) {
            values.delete(id);
        }
    };
}
export function session(options = {}) {
    const cookieName = options.cookieName ?? "nelysia_session";
    const ttlSeconds = options.ttlSeconds ?? 86400;
    if (!/^[A-Za-z0-9_-]+$/.test(cookieName))
        throw new Error("session cookieName must be a safe cookie token");
    if (!Number.isInteger(ttlSeconds) || ttlSeconds <= 0)
        throw new Error("session ttlSeconds must be a positive integer");
    const store = options.store ?? memorySessionStore();
    const generateId = options.generateId ?? (() => crypto.randomUUID());
    return ((app) => {
        const sessionGuard = async (context) => {
            const id = context.cookies[cookieName];
            if (id === undefined) {
                if (isOptionalAuth(context))
                    return;
                return context.response(401, { error: "Unauthorized" });
            }
            const value = await store.get(id);
            if (value === undefined) {
                if (isOptionalAuth(context))
                    return;
                return context.response(401, { error: "Unauthorized" });
            }
            context.auth = value;
        };
        app.registerAuthStrategy("session", { guard: sessionGuard });
        return app.derive((context) => ({
            session: createSessionApi(context, store, cookieName, ttlSeconds, generateId)
        }));
    });
}
function isOptionalAuth(context) {
    const auth = context.route?.auth;
    return typeof auth === "object" && auth !== null && auth.optional === true;
}
function createSessionApi(context, store, cookieName, ttlSeconds, generateId) {
    let id = context.cookies[cookieName];
    return {
        get id() { return id; },
        async get() {
            if (id === undefined)
                return undefined;
            const value = await store.get(id);
            if (value === undefined)
                id = undefined;
            return value;
        },
        async set(value) {
            id = generateId();
            await store.set(id, value, ttlSeconds * 1000);
            context.setCookie(cookieName, id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: ttlSeconds });
            return id;
        },
        async destroy() {
            if (id !== undefined)
                await store.delete(id);
            id = undefined;
            context.deleteCookie(cookieName, { path: "/" });
        }
    };
}
//# sourceMappingURL=index.js.map