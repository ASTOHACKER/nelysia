import { type Nelysia } from "../../core/src/app.ts";
import { type RouteGraph, type RouteRecord } from "../../core/src/types.ts";
import type { Schema } from "../../core/src/schema.ts";
export { canGenerateSchema, createGeneratedMatcher, createGeneratedValidator, createSchemaIR, executeGeneratedGet, isParamsOnlyHandler, isStaticFastPathRoute, lowerSchemaIR } from "./dispatcher.ts";
export type { CompiledDispatcher, CompiledLookup, CompiledRoute, GeneratedRouteSchema, GeneratedValidator, SchemaIR, SerializedBody, ValidationOperation } from "./dispatcher.ts";
export type ExecutionLane = "COMPILED" | "SPECIALIZED" | "GENERIC";
export interface RouteAnalysis {
    method: string;
    path: string;
    execution: "compiled" | "specialized" | "generic";
    /** Stable public execution lane. Internal subtiers remain in `reason`. */
    lane: ExecutionLane;
    reason: string;
}
export type BuildTarget = "bun" | "node";
export type BuildDiagnosticCode = "NELY001" | "NELY002" | "NELY003" | "NELY101" | "NELY102" | "NELY103" | "NELY104" | "NELY105" | "NELY106" | "NELY107" | "NELY108" | "NELY109" | "NELY110" | "NELY111" | "NELY112" | "NELY113" | "NELY114" | "NELY115";
export interface BuildDiagnostic {
    code: BuildDiagnosticCode;
    severity: "info" | "warning";
    message: string;
    route?: {
        method: string;
        path: string;
    };
    /** Route field or subsystem responsible for a fallback. */
    field?: "method" | "lifecycle" | "schema" | "handler" | "auth" | "features" | "error";
}
export interface BuildManifest {
    version: 1;
    compiler: "nelysia";
    target: BuildTarget;
    entry: string;
    artifact: string;
    sourceToSource: boolean;
    generation: "standalone" | "adapter";
    /** True when the runtime adapter serves hook-free GET routes through the
     * compiled dispatcher instead of the generic router. Additive v1 field. */
    dispatcher: boolean;
    routes: RouteAnalysis[];
    diagnostics: BuildDiagnostic[];
    reproducible: true;
    cacheKey: string;
    sourceMap: string;
}
export interface BuildArtifact {
    source: string;
    manifest: BuildManifest;
    sourceMap: string;
}
export interface CompiledApplication {
    graph: RouteGraph;
    analyses: RouteAnalysis[];
    handle: Nelysia<any, any, any>["handle"];
    standaloneBlock?: {
        code: "NELY107" | "NELY110" | "NELY111" | "NELY112" | "NELY114" | "NELY115";
        reason: string;
    };
}
export declare function compile(app: Nelysia<any, any, any>): CompiledApplication;
export declare function createCompiledBunHandler(app: Nelysia<any, any, any>, fallback?: (request: Request) => Promise<Response>): (request: Request) => Response | Promise<Response>;
export declare function generateMatcherSource(routes: readonly Pick<RouteRecord, "path" | "method">[]): string;
export declare function generateValidatorSource(schema: Schema): string;
export declare function generateSerializerSource(): string;
export declare function inspect(compiled: CompiledApplication): string;
export declare function generateServerSource(options: {
    entry: string;
    target: BuildTarget;
}): string;
export declare function generateStandaloneServerSource(options: {
    entry: string;
    target: BuildTarget;
    compiled: CompiledApplication;
}): string | undefined;
export declare function generateBuildArtifact(options: {
    entry: string;
    target: BuildTarget;
    compiled: CompiledApplication;
}): BuildArtifact;
/** Explain why a route cannot be emitted into the standalone artifact. The
 * first matching rule is intentionally deterministic so diagnostics remain
 * stable across builds and can be consumed by CI tooling. */
export declare function unsupportedRouteDiagnostic(route: RouteRecord, analysisReason?: string): {
    code: BuildDiagnosticCode;
    reason: string;
    field: BuildDiagnostic["field"];
};
//# sourceMappingURL=index.d.ts.map