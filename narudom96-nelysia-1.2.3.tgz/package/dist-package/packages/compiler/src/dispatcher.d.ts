import type { Nelysia } from "../../core/src/app.ts";
import { type Context, type ResponseData, type RouteRecord } from "../../core/src/types.ts";
import type { Schema } from "../../core/src/schema.ts";
import { type SchemaIR as CoreSchemaIR, type SchemaIRNode } from "../../core/src/schema-ir.ts";
export declare const jsonContentType = "application/json; charset=utf-8";
export declare const textContentType = "text/plain; charset=utf-8";
/** Platform-neutral pre-serialized static payload. Adapters turn this into a
 * `Response` (Bun/Fetch) or raw bytes + headers (Node) without re-serializing. */
export interface SerializedBody {
    text?: string;
    bytes?: Uint8Array;
    contentType: string;
}
export interface CompiledRoute {
    route: RouteRecord;
    paramsOnly: boolean;
    /** A static route whose handler can execute without a context allocation. */
    zeroArg: boolean;
    match: (pathname: string) => Record<string, string> | undefined;
    prefixFast?: {
        prefix: string;
        paramName: string;
    };
    /** Present when the static value was serializable at compile time. */
    serialized?: SerializedBody;
    /** Build-time generated validators for deterministic request/response schemas. */
    generated?: GeneratedRouteSchema;
}
export interface GeneratedValidator {
    validate(value: unknown, path?: string): unknown;
}
export interface GeneratedRouteSchema {
    body?: GeneratedValidator;
    params?: GeneratedValidator;
    query?: GeneratedValidator;
    headers?: GeneratedValidator;
    response?: GeneratedValidator;
    responses?: Record<string, GeneratedValidator>;
}
export interface ValidationOperation {
    readonly kind: string;
    readonly path: string;
    readonly keyword?: string;
    readonly capability: "compiled" | "reference" | "unsupported";
    readonly definition: Readonly<Record<string, unknown>>;
}
/** Stable, JSON-compatible intermediate representation used by code
 * generation. Keeping this boundary separate from runtime Schema objects
 * prevents user-defined validators and mutable definitions from leaking into
 * generated artifacts. */
export type SchemaIR = Readonly<Record<string, unknown>>;
export interface CompiledDispatcher {
    routes: CompiledRoute[];
    staticMap: Map<string, CompiledRoute>;
    staticFunctionMap: Map<string, CompiledRoute>;
    single?: CompiledRoute;
    singleStatic?: CompiledRoute;
    singleDynamic?: CompiledRoute;
    needsRequestId: boolean;
    /** Contextful generic routes cannot use the minimal dispatcher context when
     * app-level state/decorations are installed; they must use app.handle(). */
    hasContextValues: boolean;
}
/**
 * Execute a deterministic GET route with the generated schema contract.
 * Runtime adapters use this shared implementation so Bun, Node, and Fetch do
 * not drift in query/context/response semantics. The caller owns error
 * adaptation through `app.handleAdapterError`.
 */
export declare function executeGeneratedGet(entry: CompiledRoute, params: Record<string, string>, request: Request, requestId?: string): Promise<ResponseData>;
export type CompiledLookup = {
    kind: "static-prebuilt";
    entry: CompiledRoute;
} | {
    kind: "static-sync";
    entry: CompiledRoute;
} | {
    kind: "params";
    entry: CompiledRoute;
    params: Record<string, string>;
} | {
    kind: "generic";
    entry: CompiledRoute;
    params: Record<string, string>;
};
/**
 * Routes eligible for the compiled fast path. Body parsing remains owned by
 * the runtime adapter, but deterministic body definitions are still emitted
 * into the route IR so standalone/runtime integrations can consume the same
 * generated validator without invoking user code.
 */
export declare function isCompilableRoute(route: RouteRecord): boolean;
/** A route may enter the minimal static dispatcher only when no request or
 * response contract needs runtime validation. Schema-bearing routes remain on
 * the generated-validation adapter path even when their URL is static. */
export declare function isStaticFastPathRoute(route: RouteRecord): boolean;
export type ExecutionLane = "COMPILED" | "SPECIALIZED" | "GENERIC";
/** Public diagnostic mirror of the compiler's route lane selection. */
export declare function classifyRouteLane(route: RouteRecord, contextFree?: boolean): ExecutionLane;
export declare function serializeStaticValue(value: unknown): SerializedBody | undefined;
export declare function compileDispatcher(app: Nelysia<any, any, any>): CompiledDispatcher;
/** Return true only for schemas whose definition is sufficient to reproduce
 * the built-in validator without invoking user code. Standard Schema objects,
 * transforms, and unknown keywords intentionally use the generic runtime. */
export declare function canGenerateSchema(schema: Schema | undefined): boolean;
export declare function lowerSchemaIR(ir: CoreSchemaIR | SchemaIRNode): ValidationOperation[];
export declare function createGeneratedValidator(definition: Record<string, unknown>): GeneratedValidator;
export declare function createSchemaIR(schema: Schema | undefined): SchemaIR | undefined;
/** Shared dispatch core: O(1) static hit, single-route shortcuts, then a
 * per-method-order scan. Returns undefined when the generic fallback owns it. */
export declare function lookupCompiled(dispatcher: CompiledDispatcher, pathname: string): CompiledLookup | undefined;
export declare function matchPrefix(spec: {
    prefix: string;
    paramName: string;
}, path: string): Record<string, string> | undefined;
export declare function matchSingleDynamicUrl(entry: {
    prefixFast?: {
        prefix: string;
        paramName: string;
    };
}, url: string): Record<string, string> | undefined;
export declare function fastPathname(url: string): string;
export declare function createGeneratedMatcher(route: RouteRecord): (pathname: string) => Record<string, string> | undefined;
export declare function isParamsOnlyHandler(handler: (context: Context) => unknown): boolean;
//# sourceMappingURL=dispatcher.d.ts.map