import { HttpError } from "../../core/src/types.js";
import { responseMarker } from "../../core/src/types.js";
import { createBunRuntimeHandler } from "../../runtime-bun/src/handler.js";
import { canGenerateSchema, compileDispatcher, createSchemaIR, executeGeneratedGet, fastPathname, isCompilableRoute, isParamsOnlyHandler, isStaticFastPathRoute, jsonContentType, lookupCompiled, matchSingleDynamicUrl, serializeStaticValue } from "./dispatcher.js";
import { createHash } from "node:crypto";
export { canGenerateSchema, createGeneratedMatcher, createGeneratedValidator, createSchemaIR, executeGeneratedGet, isParamsOnlyHandler, isStaticFastPathRoute, lowerSchemaIR } from "./dispatcher.js";
export function compile(app) {
    const analyses = app.graph.routes.map((route) => {
        const eligible = isCompilableRoute(route);
        const compiled = eligible && isStaticFastPathRoute(route) && route.contextFree;
        const zeroArg = eligible && isStaticFastPathRoute(route) && route.handler.length === 0;
        const params = eligible && !route.static && isParamsOnlyHandler(route.handler) && route.hooks.length === 0;
        const generatedSchema = eligible && hasGeneratedSchema(route);
        const specialized = eligible && (route.static || params || generatedSchema);
        return {
            method: route.method,
            path: route.path,
            execution: compiled ? "compiled" : specialized ? "specialized" : "generic",
            lane: compiled || zeroArg ? "COMPILED" : specialized ? "SPECIALIZED" : "GENERIC",
            reason: compiled
                ? "Explicit static response; adapter uses static-prebuilt dispatch"
                : zeroArg
                    ? "Static zero-arg handler; adapter uses static-sync dispatch"
                    : generatedSchema ? "Generated schema validation uses the specialized adapter path"
                        : isStandaloneRoute(route) ? "Handler and schema source can be embedded" : unsupportedRouteDiagnostic(route).reason
        };
    });
    const standaloneBlock = app.hasContextValues
        ? { code: "NELY112", reason: "Application state or decorations require the full request context" }
        : app.telemetry !== undefined
            ? { code: "NELY111", reason: "Telemetry requires the generic runtime" }
            : app.bodyLimit !== 1024 * 1024 || app.usesTrustedProxy || app.usesSecureCookies || app.hasCustomNotFound
                ? { code: "NELY114", reason: "Application options require the runtime adapter" }
                : app.hasGlobalLifecycle
                    ? { code: "NELY115", reason: "Application response/request lifecycle cannot be embedded safely" }
                    : app.websocketRoutes.length > 0
                        ? { code: "NELY110", reason: "WebSocket routes require the runtime adapter" }
                        : app.hasFetchMounts
                            ? { code: "NELY107", reason: "Mounted Fetch handlers require the runtime adapter" }
                            : undefined;
    return { graph: app.graph, analyses, handle: app.handle.bind(app), standaloneBlock };
}
export function createCompiledBunHandler(app, fallback) {
    const genericFallback = fallback ?? createBunRuntimeHandler(app);
    const useFallback = app.telemetry !== undefined || app.hasGlobalLifecycle || app.hasFetchMounts;
    // Shared Headers instances: Bun normalizes plain-object headers on every
    // construction (~1.8M/s) but reuses Headers instances (~2.8M/s).
    // Keep adapter headers identical to the reference runtime. In particular,
    // do not add an adapter-only `server` header or normalize the text charset
    // differently on the prebuilt lane.
    const jsonHeaders = new Headers({ "content-type": "application/json; charset=utf-8" });
    const textHeaders = new Headers({ "content-type": "text/plain;charset=UTF-8" });
    const dispatcher = useFallback ? undefined : compileDispatcher(app);
    // A lifecycle-heavy application may have no compilable routes at all. In
    // that case the dispatcher cannot ever produce a hit, so return the runtime
    // fallback directly instead of paying a route-map probe on every request.
    if (dispatcher === undefined || dispatcher.routes.length === 0)
        return genericFallback;
    // Bun-specific prebuilt responses from platform-neutral payloads.
    const prebuilt = new Map();
    if (dispatcher !== undefined) {
        for (const entry of dispatcher.routes) {
            const serialized = entry.serialized;
            if (entry.route.static && serialized !== undefined) {
                const headers = serialized.contentType === jsonContentType ? jsonHeaders : textHeaders;
                prebuilt.set(entry, serialized.text !== undefined
                    ? new Response(serialized.text, { status: 200, headers })
                    : new Response(serialized.bytes, { status: 200, headers }));
            }
        }
    }
    return (request) => {
        if (dispatcher === undefined)
            return genericFallback(request);
        // Fast guard: method check only. Compiled GET routes declare no body schema,
        // so a body on GET is ignored per GET semantics — no Headers/body access here.
        if (request.method !== "GET")
            return genericFallback(request);
        const requestId = dispatcher.needsRequestId
            ? request.headers.get("x-request-id") ?? crypto.randomUUID()
            : undefined;
        // Single-dynamic shortcut: extract the param straight from the URL,
        // skipping the intermediate pathname slice (benchmark /users/:id case).
        if (dispatcher.singleDynamic !== undefined) {
            const params = matchSingleDynamicUrl(dispatcher.singleDynamic, request.url);
            if (params !== undefined)
                return runParamsOnly(dispatcher.singleDynamic, params, request, requestId);
            return genericFallback(request);
        }
        const found = lookupCompiled(dispatcher, fastPathname(request.url));
        if (found === undefined)
            return genericFallback(request);
        // A context-free static route can still use the zero-allocation lane when
        // an application has decorations (for example JWT on public routes).
        // Params-only handlers receive a synthetic context, so contextful apps
        // must use the reference runtime for those routes.
        if (dispatcher.hasContextValues && found.kind === "params")
            return genericFallback(request);
        switch (found.kind) {
            case "static-prebuilt":
                return withRequestId(prebuilt.get(found.entry).clone(), requestId);
            case "static-sync": {
                // Static function routes are context-free but their value is only known
                // at request time. Execute once, preserve native results, and keep the
                // error path out of the hot response pipeline.
                return runStaticFunction(found.entry, request, requestId);
            }
            case "params":
                return runParamsOnly(found.entry, found.params, request, requestId);
            case "generic":
                // Generated schemas are safe to execute here only when the app has no
                // per-request decorations/state to hydrate. Routes with opaque
                // behavior remain on the reference adapter, preserving the exact
                // generic lifecycle contract.
                if (found.entry.generated === undefined || dispatcher.hasContextValues)
                    return genericFallback(request);
                return runGeneric(found.entry, found.params, request, requestId);
        }
    };
    function runParamsOnly(c, params, request, requestId) {
        try {
            const result = c.route.handler({ params });
            if (isPromiseLike(result))
                return Promise.resolve(result).then((value) => resolveFastResult(value, request, requestId), (error) => handleFastError(error, request, requestId));
            return fastJson(result, 200, undefined, requestId);
        }
        catch (error) {
            return handleFastError(error, request, requestId);
        }
    }
    function runStaticFunction(c, request, requestId) {
        try {
            const result = c.route.handler();
            if (isPromiseLike(result))
                return Promise.resolve(result).then((value) => resolveFastResult(value, request, requestId), (error) => handleFastError(error, request, requestId));
            return fastJson(result, 200, undefined, requestId);
        }
        catch (error) {
            return handleFastError(error, request, requestId);
        }
    }
    function resolveFastResult(value, request, requestId) {
        try {
            return fastJson(value, 200, undefined, requestId);
        }
        catch (error) {
            return handleFastError(error, request, requestId);
        }
    }
    async function handleFastError(error, request, requestId) {
        const result = await app.handleAdapterError(error, {
            method: request.method,
            url: request.url,
            headers: request.headers,
            signal: request.signal,
            requestId
        });
        return responseFromResult(result.status, result.headers, result.body, requestId);
    }
    function runGeneric(entry, params, request, requestId) {
        return executeGeneratedGet(entry, params, request, requestId).then((result) => responseFromResult(result.status, result.headers, result.body, requestId), (error) => handleFastError(error, request, requestId));
    }
    function fastJson(value, status = 200, headers, requestId) {
        if (value instanceof HttpError)
            throw value;
        if (isResponseData(value))
            return responseFromResult(value.status, value.headers, value.body, requestId);
        if (value instanceof Response) {
            if (requestId === undefined)
                return value;
            const responseHeaders = new Headers(value.headers);
            responseHeaders.set("x-request-id", requestId);
            return new Response(value.body, { status: value.status, headers: responseHeaders });
        }
        // Keep the object lane separate from text/bytes. The previous version
        // allocated text headers before discovering that the value was JSON, then
        // allocated a second JSON header set. A single base-header preparation is
        // enough and preserves the exact charset-bearing content-type contract.
        if (typeof value === "string" || value instanceof Uint8Array || value instanceof ReadableStream || value === undefined || value === null) {
            const responseHeaders = fastHeaders(textHeaders, headers, requestId);
            if (value instanceof ReadableStream)
                return new Response(value, { status, headers: responseHeaders });
            if (value === undefined || value === null)
                return new Response(null, { status, headers: responseHeaders });
            return new Response(value, { status, headers: responseHeaders });
        }
        // Do not cache this serialization: zero-arg handlers are allowed to return
        // request-varying objects, so each invocation must observe fresh state.
        return new Response(JSON.stringify(value), { status, headers: fastHeaders(jsonHeaders, headers, requestId) });
    }
}
function fastHeaders(base, overrides, requestId) {
    if (overrides === undefined && requestId === undefined)
        return base;
    const headers = new Headers(base);
    if (overrides !== undefined)
        for (const [name, value] of Object.entries(overrides))
            headers.set(name, value);
    if (requestId !== undefined)
        headers.set("x-request-id", requestId);
    return headers;
}
function responseFromResult(status, headers, body, requestId) {
    const responseHeaders = new Headers(headers);
    if (requestId !== undefined)
        responseHeaders.set("x-request-id", requestId);
    if (body instanceof Response) {
        if (requestId === undefined && headers === undefined)
            return body;
        for (const [key, value] of body.headers)
            responseHeaders.set(key, value);
        return new Response(body.body, { status: body.status, headers: responseHeaders });
    }
    if (body instanceof ReadableStream)
        return new Response(body, { status, headers: responseHeaders });
    if (body === undefined || body === null)
        return new Response(null, { status, headers: responseHeaders });
    if (typeof body === "string" || body instanceof Uint8Array) {
        const outputHeaders = responseHeaders.has("content-type") ? responseHeaders : new Headers({ ...Object.fromEntries(responseHeaders.entries()), "content-type": "text/plain;charset=UTF-8" });
        return new Response(body, { status, headers: outputHeaders });
    }
    if (!responseHeaders.has("content-type"))
        responseHeaders.set("content-type", "application/json; charset=utf-8");
    return new Response(JSON.stringify(body), { status, headers: responseHeaders });
}
function withRequestId(response, requestId) {
    if (requestId === undefined)
        return response;
    response.headers.set("x-request-id", requestId);
    return response;
}
function isPromiseLike(value) {
    return typeof value === "object" && value !== null && typeof value.then === "function";
}
function isResponseOptions(value) {
    return typeof value === "object" && value !== null && ("status" in value || "headers" in value);
}
function requestPath(input) {
    let value = input;
    const scheme = value.indexOf("://");
    if (scheme !== -1) {
        const slash = value.indexOf("/", scheme + 3);
        value = slash === -1 ? "/" : value.slice(slash);
    }
    const query = value.indexOf("?");
    return (query === -1 ? value : value.slice(0, query)) || "/";
}
function requestQuery(input) {
    const index = input.indexOf("?");
    return index === -1 ? "" : input.slice(index + 1);
}
export function generateMatcherSource(routes) {
    const definitions = JSON.stringify(routes.map(({ method, path }) => ({ method, path })));
    return `const routes = ${definitions}\nexport function matchGeneratedRoute(method, pathname) {\n  for (const route of routes) {\n    if (route.method !== method) continue\n    const pattern = route.path.split("/").filter(Boolean)\n    const values = pathname.split("/").filter(Boolean)\n    if (pattern.at(-1) === "*" ? values.length < pattern.length - 1 : pattern.length !== values.length) continue\n    const params = {}\n    let matched = true\n    for (let index = 0; index < pattern.length; index++) {\n      if (pattern[index] === "*") { try { params["*"] = values.slice(index).map((value) => decodeURIComponent(value)).join("/") } catch { matched = false } break }\n      if (pattern[index].startsWith(":")) { try { params[pattern[index].slice(1)] = decodeURIComponent(values[index]) } catch { matched = false } }\n      else if (pattern[index] !== values[index]) matched = false\n    }\n    if (matched) return { route, params }\n  }\n}\n`;
}
export function generateValidatorSource(schema) {
    const definition = JSON.stringify(createSchemaIR(schema) ?? schema.definition ?? { type: schema.kind });
    return `const definition = ${definition}
function setSafe(output, key, value) {
  if (key === "__proto__" || key === "constructor" || key === "prototype") Object.defineProperty(output, key, { value, enumerable: true, configurable: true, writable: true })
  else output[key] = value
}
const invalid = (message) => Object.assign(new Error(message), { status: 400 })
function validate(value, schema, path) {
  if (!schema || Object.keys(schema).length === 0) return value
  if (schema["x-nelysia-optional"] === true && value === undefined) return undefined
  if ("const" in schema && value !== schema.const) throw invalid(path + " must equal " + String(schema.const))
  if (Array.isArray(schema.enum) && !schema.enum.some((entry) => Object.is(entry, value))) throw invalid(path + " must be an allowed value")
  if (Array.isArray(schema.anyOf)) {
    const errors = []
    for (const branch of schema.anyOf) {
      try { return validate(value, branch, path) } catch (error) { errors.push(String(error && error.message || error)) }
    }
    throw invalid(path + " does not match any allowed value: " + errors.join("; "))
  }
  if (Array.isArray(schema.allOf)) { let output = value; for (const branch of schema.allOf) { const validated = validate(output, branch, path); output = output && typeof output === "object" && validated && typeof validated === "object" ? { ...output, ...validated } : validated } return output }
  if (schema.type === "never") throw invalid(path + " must be never")
  if (schema.type === "null") { if (value !== null) throw invalid(path + " must be null"); return value }
  if (schema.type === "string") {
    if (typeof value !== "string") throw invalid(path + " must be string")
    if (schema.minLength !== undefined && Array.from(value).length < schema.minLength) throw invalid(path + " is too short")
    if (schema.maxLength !== undefined && Array.from(value).length > schema.maxLength) throw invalid(path + " is too long")
    if (schema.pattern !== undefined && !(new RegExp(schema.pattern, schema["x-patternFlags"] || "")).test(value)) throw invalid(path + " has an invalid format")
    if (schema.format === "date-time" && Number.isNaN(Date.parse(value))) throw invalid(path + " must be a date-time")
    if (schema.format === "date" && (!/^\\d{4}-\\d{2}-\\d{2}$/.test(value) || Number.isNaN(Date.parse(value + "T00:00:00Z")))) throw invalid(path + " has an invalid format")
    if (schema.format === "email" && !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(value)) throw invalid(path + " has an invalid format")
    if (schema.format === "uuid" && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) throw invalid(path + " has an invalid format")
    if (schema.format === "url" || schema.format === "uri") { try { new URL(value) } catch { throw invalid(path + " has an invalid format") } }
    if (schema.format === "ipv4" && !/^(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2})){3}$/.test(value)) throw invalid(path + " has an invalid format")
    if (schema.format === "ipv6" && !value.includes(":")) throw invalid(path + " has an invalid format")
    if (schema.format === "hostname" && !/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/.test(value)) throw invalid(path + " has an invalid format")
    return value
  }
  if (schema["x-nelysia-kind"] === "bigint") {
    if (typeof value !== "bigint") throw invalid(path + " must be bigint")
    const option = (key) => typeof schema[key] === "string" && /^-?\d+$/.test(schema[key]) ? BigInt(schema[key]) : undefined
    const minimum = option("minimum")
    const maximum = option("maximum")
    const exclusiveMinimum = option("exclusiveMinimum")
    const exclusiveMaximum = option("exclusiveMaximum")
    const multipleOf = option("multipleOf")
    if (minimum !== undefined && value < minimum) throw invalid(path + " is below minimum")
    if (maximum !== undefined && value > maximum) throw invalid(path + " is above maximum")
    if (exclusiveMinimum !== undefined && value <= exclusiveMinimum) throw invalid(path + " is below exclusive minimum")
    if (exclusiveMaximum !== undefined && value >= exclusiveMaximum) throw invalid(path + " is above exclusive maximum")
    if (multipleOf !== undefined && value % multipleOf !== 0n) throw invalid(path + " must be a multiple of " + multipleOf)
    return value
  }
  if (schema.type === "number" || schema.type === "integer") {
    if (typeof value !== "number" || !Number.isFinite(value) || (schema.type === "integer" && !Number.isInteger(value))) throw invalid(path + " must be " + schema.type)
    if (schema.minimum !== undefined && value < schema.minimum) throw invalid(path + " is below minimum")
    if (schema.maximum !== undefined && value > schema.maximum) throw invalid(path + " is above maximum")
    if (schema.exclusiveMinimum !== undefined && value <= schema.exclusiveMinimum) throw invalid(path + " is below exclusive minimum")
    if (schema.exclusiveMaximum !== undefined && value >= schema.exclusiveMaximum) throw invalid(path + " is above exclusive maximum")
    if (typeof schema.multipleOf === "number" && schema.multipleOf > 0) { const quotient = value / schema.multipleOf; if (Math.abs(quotient - Math.round(quotient)) > Number.EPSILON * Math.max(1, Math.abs(quotient))) throw invalid(path + " must be a multiple of " + schema.multipleOf) }
    return value
  }
  if (schema.type === "boolean") { if (typeof value !== "boolean") throw invalid(path + " must be boolean"); return value }
  if (schema.type === "array") {
    if (!Array.isArray(value)) throw invalid(path + " must be array")
    if (schema.minItems !== undefined && value.length < schema.minItems) throw invalid(path + " has too few items")
    if (schema.maxItems !== undefined && value.length > schema.maxItems) throw invalid(path + " has too many items")
    if (schema.uniqueItems === true && new Set(value.map((entry) => JSON.stringify(entry) ?? String(entry))).size !== value.length) throw invalid(path + " must contain unique items")
    if (Array.isArray(schema.prefixItems)) {
      if (value.length !== schema.prefixItems.length) throw invalid(path + " has an invalid tuple length")
      return value.map((entry, index) => validate(entry, schema.prefixItems[index], path + "." + index))
    }
    return value.map((entry, index) => validate(entry, schema.items, path + "." + index))
  }
  if (schema.type === "object") {
    if (value === null || typeof value !== "object" || Array.isArray(value)) throw invalid(path + " must be object")
    const input = value
    for (const key of schema.required || []) if (input[key] === undefined) throw invalid(path + "." + key + " is required")
    const output = {}
    if (schema.minProperties !== undefined && Object.keys(value).length < schema.minProperties) throw invalid(path + " must have at least " + schema.minProperties + " properties")
    if (schema.maxProperties !== undefined && Object.keys(value).length > schema.maxProperties) throw invalid(path + " must have at most " + schema.maxProperties + " properties")
    for (const [key, child] of Object.entries(schema.properties || {})) if (input[key] !== undefined) setSafe(output, key, validate(input[key], child, path + "." + key))
    const patternFor = (key) => { for (const [pattern, child] of Object.entries(schema.patternProperties || {})) { try { if (new RegExp(pattern).test(key)) return child } catch {} } }
    if (schema.additionalProperties === false) for (const key of Object.keys(value)) if ((!schema.properties || !Object.prototype.hasOwnProperty.call(schema.properties, key)) && !patternFor(key)) throw invalid(path + " must not contain additional properties")
    for (const [key, entry] of Object.entries(input)) {
      if (schema.properties && Object.prototype.hasOwnProperty.call(schema.properties, key)) continue
      const pattern = patternFor(key)
      if (pattern) setSafe(output, key, validate(entry, pattern, path + "." + key))
      else if (schema.additionalProperties === true || schema.patternProperties) setSafe(output, key, entry)
      else if (schema.additionalProperties && typeof schema.additionalProperties === "object") setSafe(output, key, validate(entry, schema.additionalProperties, path + "." + key))
    }
    return output
  }
  return value
}
export function validateGenerated(value, path = "body") { return validate(value, definition, path) }
`;
}
export function generateSerializerSource() {
    return `export function serializeGenerated(value) {\n  return JSON.stringify(value)\n}\n`;
}
function isResponseData(value) {
    return typeof value === "object" && value !== null && value[responseMarker] === true;
}
export function inspect(compiled) {
    return compiled.analyses.map((route) => `${route.method} ${route.path}\n  Execution: ${route.execution.toUpperCase()}\n  Lane: ${route.lane}\n  Reason: ${route.reason}`).join("\n");
}
export function generateServerSource(options) {
    const entry = options.entry.startsWith(".") ? options.entry : `./${options.entry}`;
    if (options.target === "bun") {
        return `import { app } from ${JSON.stringify(entry)}\nimport { createCompiledBunHandler } from "@narudom96/nelysia/compiler"\n\nconst port = Number(process.env.PORT ?? 3000)\nconst server = Bun.serve({ port, fetch: createCompiledBunHandler(app) })\nconsole.log(\`Nelysia compiled Bun server listening on http://localhost:\${server.port}\`)\n`;
    }
    return `import { app } from ${JSON.stringify(entry)}\nimport { createNodeServer } from "@narudom96/nelysia/runtime-node"\n\nconst port = Number(process.env.PORT ?? 3000)\ncreateNodeServer(app).listen(port, () => console.log(\`Nelysia compiled Node server listening on http://localhost:\${port}\`))\n`;
}
export function generateStandaloneServerSource(options) {
    if (options.compiled.standaloneBlock !== undefined)
        return;
    if (!options.compiled.graph.routes.every(isStandaloneRoute))
        return;
    const routes = options.compiled.graph.routes.map((route) => {
        const handler = route.staticValue !== undefined ? `() => ${literalSource(route.staticValue)}` : functionSource(route.handler);
        const functions = (values) => `[${(values ?? []).map(functionSource).join(",")}]`;
        const schema = (value) => value === undefined || !canGenerateSchema(value) ? "undefined" : JSON.stringify(value.definition);
        const responseSchemas = Object.fromEntries(Object.entries(route.responseSchemas ?? {}).filter(([, value]) => canGenerateSchema(value)).map(([status, value]) => [status, JSON.stringify(value.definition)]));
        return `{ method: ${JSON.stringify(route.method)}, path: ${JSON.stringify(route.path)}, handler: ${handler}, requestHooks: ${functions(route.requestHooks)}, parseHooks: ${functions(route.parseHooks)}, hooks: ${functions(route.hooks)}, mapResponseHooks: ${functions(route.mapResponseHooks)}, afterHooks: ${functions(route.afterHooks)}, afterResponseHooks: ${functions(route.afterResponseHooks)}, errorHandlers: ${functions(route.errorHandlers)}, bodySchema: ${schema(route.bodySchema)}, paramsSchema: ${schema(route.paramsSchema)}, querySchema: ${schema(route.querySchema)}, headersSchema: ${schema(route.headersSchema)}, responseSchema: ${schema(route.responseSchema)}, responseSchemas: ${JSON.stringify(responseSchemas)} }`;
    }).join(",\n");
    const handler = `const routes = [${routes}]
const mergeHeaders = (base, extra) => { const headers = new Headers(base); for (const [key, value] of new Headers(extra || {}).entries()) headers.set(key, value); return headers }
const match = (route, pathname) => { const pattern = route.path.split("/").filter(Boolean); const values = pathname.split("/").filter(Boolean); if (pattern.at(-1) === "*" ? values.length < pattern.length - 1 : pattern.length !== values.length) return; const params = {}; for (let index = 0; index < pattern.length; index++) { if (pattern[index] === "*") { try { params["*"] = values.slice(index).map((value) => decodeURIComponent(value)).join("/") } catch { return } break } if (pattern[index].startsWith(":")) { try { params[pattern[index].slice(1)] = decodeURIComponent(values[index]) } catch { return } } else if (pattern[index] !== values[index]) return } return params }
const isData = (value) => value && typeof value === "object" && value.__nelysiaResponse === true
const data = (status, body, headers) => ({ status, body, headers: new Headers(headers), __nelysiaResponse: true })
const toResponse = (value, context, status = context.set.status || 200) => { if (value instanceof Response) return value; if (isData(value)) { if (value.body instanceof Response) return value.body; const headers = mergeHeaders(context.responseHeaders, value.headers); if (value.body === undefined || value.body === null) return new Response(null, { status: value.status, headers }); if (value.body instanceof ReadableStream) return new Response(value.body, { status: value.status, headers }); if (typeof value.body === "string" || value.body instanceof Uint8Array) { if (!headers.has("content-type")) headers.set("content-type", "text/plain; charset=utf-8"); return new Response(value.body, { status: value.status, headers }) } if (!headers.has("content-type")) headers.set("content-type", "application/json; charset=utf-8"); return new Response(JSON.stringify(value.body), { status: value.status, headers }) } if (value === undefined || value === null) return new Response(null, { status, headers: context.responseHeaders }); if (typeof value === "string" || value instanceof Uint8Array) return new Response(value, { status, headers: mergeHeaders(context.responseHeaders, { "content-type": "text/plain; charset=utf-8" }) }); return new Response(JSON.stringify(value), { status, headers: mergeHeaders(context.responseHeaders, { "content-type": "application/json; charset=utf-8" }) }) }
const validate = ${standaloneValidatorSource()}
const parseBody = async (request) => { if (request.method === "GET" || request.method === "HEAD") return undefined; const text = await request.text(); if (!text) return undefined; if (request.headers.get("content-type")?.includes("application/json")) { try { return JSON.parse(text) } catch { throw Object.assign(new Error("Malformed JSON body"), { status: 400 }) } } return text }
const makeContext = (request, params, body, url) => { const responseHeaders = new Headers({ "x-request-id": request.headers.get("x-request-id") || "" }); const context = { request: { method: request.method, url: request.url, headers: request.headers, body }, requestId: request.headers.get("x-request-id") || "", params, query: new URLSearchParams(url.search), body, headers: request.headers, cookies: {}, set: { status: undefined, headers: {} }, store: {}, responseHeaders, response: (bodyOrStatus, optionsOrBody, extraHeaders) => { const bodyFirst = typeof bodyOrStatus !== "number" || (extraHeaders === undefined && optionsOrBody && typeof optionsOrBody === "object" && ("status" in optionsOrBody || "headers" in optionsOrBody)); if (!bodyFirst) return data(bodyOrStatus, optionsOrBody, mergeHeaders(responseHeaders, extraHeaders)); const options = optionsOrBody || {}; return data(options.status || 200, bodyOrStatus, mergeHeaders(responseHeaders, options.headers)); }, html: (value, status = 200) => data(status, value, mergeHeaders(responseHeaders, { "content-type": "text/html; charset=utf-8" })), text: (value, status = 200) => data(status, value, mergeHeaders(responseHeaders, { "content-type": "text/plain; charset=utf-8" })), json: (value, status = 200) => data(status, value, mergeHeaders(responseHeaders, { "content-type": "application/json; charset=utf-8" })), redirect: (value, status = 302) => data(status, undefined, mergeHeaders(responseHeaders, { location: value })), header: (name, value) => { context.set.headers[name.toLowerCase()] = value; return context }, setCookie: (name, value) => responseHeaders.append("set-cookie", name + "=" + encodeURIComponent(value) + "; Path=/"), deleteCookie: (name) => responseHeaders.append("set-cookie", name + "=; Max-Age=0; Path=/") }; return context }
const allowFor = (pathname) => [...new Set(routes.filter((route) => match(route, pathname) !== undefined).map((route) => route.method === "GET" ? ["GET", "HEAD"] : [route.method]).flat())].concat(["OPTIONS"]).join(", ")
export const handle = async (request) => { const url = new URL(request.url); const pathname = url.pathname; const method = request.method === "HEAD" ? "GET" : request.method; const matching = routes.filter((route) => match(route, pathname) !== undefined); if (request.method === "OPTIONS" && matching.length > 0 && !routes.some((candidate) => candidate.method === "OPTIONS" && match(candidate, pathname) !== undefined)) return new Response(null, { status: 204, headers: { allow: allowFor(pathname) } }); const route = routes.find((candidate) => candidate.method === method && match(candidate, pathname) !== undefined); if (!route) return matching.length > 0 ? new Response(JSON.stringify({ error: "Method Not Allowed" }), { status: 405, headers: { allow: allowFor(pathname), "content-type": "application/json; charset=utf-8" } }) : new Response(JSON.stringify({ error: "Not Found" }), { status: 404, headers: { "content-type": "application/json; charset=utf-8" } }); const context = makeContext(request, match(route, pathname), await parseBody(request), url); try { let parsedRequest = context.request; for (const hook of route.requestHooks) { const result = await hook(parsedRequest); if (result instanceof Response) return result } for (const hook of route.parseHooks) { const parsed = await hook(parsedRequest, request.headers.get("content-type")); if (parsed !== undefined) { parsedRequest = { ...parsedRequest, body: parsed }; context.body = parsed } } if (route.paramsSchema) context.params = validate(context.params, route.paramsSchema, "params"); if (route.querySchema) context.query = new URLSearchParams(Object.entries(validate(Object.fromEntries(context.query.entries()), route.querySchema, "query")).map(([key, value]) => [key, String(value)])); if (route.headersSchema) validate(Object.fromEntries(context.headers.entries()), route.headersSchema, "headers"); if (route.bodySchema) context.body = validate(context.body, route.bodySchema, "body"); for (const hook of route.hooks) { const result = await hook(context); if (result instanceof Response || isData(result)) return result } let result = await route.handler(context); let response = isData(result) ? result : data(context.set.status || 200, result, mergeHeaders(context.responseHeaders, context.set.headers)); const responseSchema = route.responseSchemas && (route.responseSchemas[String(response.status)] || route.responseSchemas.default) || (response.status === 200 ? route.responseSchema : undefined); if (responseSchema && !(response.body instanceof Response) && !(response.body instanceof ReadableStream)) response.body = validate(response.body, responseSchema, "response"); for (const hook of route.mapResponseHooks) { const mapped = await hook(context, response); if (mapped instanceof Response || isData(mapped)) response = mapped; else if (mapped !== undefined) response.body = mapped } for (const hook of route.afterHooks) await hook(context, response); const output = toResponse(response, context); for (const hook of route.afterResponseHooks) await hook(context, response); return request.method === "HEAD" ? new Response(null, { status: output.status, headers: output.headers }) : output } catch (error) { context.set.status = error && error.status || 500; for (const hook of route.errorHandlers) { const result = await hook(error, context); if (result instanceof Response) return result; if (isData(result)) return toResponse(result, context); if (result !== undefined) return toResponse(data(context.set.status, result, context.responseHeaders), context) } return new Response(JSON.stringify({ error: error && error.message || "Internal Server Error" }), { status: context.set.status, headers: mergeHeaders(context.responseHeaders, { "content-type": "application/json; charset=utf-8" }) }) } }
`;
    if (options.target === "bun")
        return `${handler}\nconst port = Number(process.env.PORT ?? 3000)\nconst server = Bun.serve({ port, fetch: handle })\nconsole.log(\`Nelysia standalone Bun server listening on http://localhost:\${server.port}\`)\n`;
    return `import http from "node:http"\n${handler}\nconst port = Number(process.env.PORT ?? 3000)\nhttp.createServer(async (request, response) => { const chunks = []; for await (const chunk of request) chunks.push(chunk); const body = chunks.length > 0 ? Buffer.concat(chunks) : undefined; const result = await handle(new Request(\`http://localhost\${request.url}\`, { method: request.method, headers: request.headers as HeadersInit, body: body?.length ? new Uint8Array(body) : undefined })); response.writeHead(result.status, Object.fromEntries(result.headers)); response.end(new Uint8Array(await result.arrayBuffer())) }).listen(port, () => console.log(\`Nelysia standalone Node server listening on http://localhost:\${port}\`))\n`;
}
function standaloneValidatorSource() {
    return String.raw `(value, schema, path) => {
  const invalid = (message) => Object.assign(new Error(message), { status: 400 })
  const setSafe = (output, key, entry) => {
    if (key === "__proto__" || key === "constructor" || key === "prototype") Object.defineProperty(output, key, { value: entry, enumerable: true, configurable: true, writable: true })
    else output[key] = entry
  }
  const validate = (current, definition, location) => {
    if (!definition || Object.keys(definition).length === 0) return current
    if (definition["x-nelysia-optional"] === true && current === undefined) return undefined
    if ("const" in definition && current !== definition.const) throw invalid(location + " must equal " + String(definition.const))
    if (Array.isArray(definition.enum) && !definition.enum.some((entry) => Object.is(entry, current))) throw invalid(location + " must be an allowed value")
    if (Array.isArray(definition.anyOf)) {
      const errors = []
      for (const branch of definition.anyOf) {
        try { return validate(current, branch, location) } catch (error) { errors.push(String(error && error.message || error)) }
      }
      throw invalid(location + " does not match any allowed value: " + errors.join("; "))
    }
    if (Array.isArray(definition.allOf)) {
      let output = current
      for (const branch of definition.allOf) {
        const validated = validate(output, branch, location)
        output = output && typeof output === "object" && validated && typeof validated === "object" ? { ...output, ...validated } : validated
      }
      return output
    }
    if (definition.type === "never") throw invalid(location + " must be never")
    if (definition.type === "null") { if (current !== null) throw invalid(location + " must be null"); return current }
    if (definition.type === "string") {
      if (typeof current !== "string") throw invalid(location + " must be string")
      if (typeof definition.minLength === "number" && Array.from(current).length < definition.minLength) throw invalid(location + " is too short")
      if (typeof definition.maxLength === "number" && Array.from(current).length > definition.maxLength) throw invalid(location + " is too long")
      if (typeof definition.pattern === "string" && !(new RegExp(definition.pattern, typeof definition["x-patternFlags"] === "string" ? definition["x-patternFlags"] : "")).test(current)) throw invalid(location + " has an invalid format")
      if (definition.format === "date-time" && Number.isNaN(Date.parse(current))) throw invalid(location + " must be a date-time")
      if (definition.format === "date" && (!/^\d{4}-\d{2}-\d{2}$/.test(current) || Number.isNaN(Date.parse(current + "T00:00:00Z")))) throw invalid(location + " has an invalid format")
      if (definition.format === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(current)) throw invalid(location + " has an invalid format")
      if (definition.format === "uuid" && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(current)) throw invalid(location + " has an invalid format")
      if (definition.format === "url" || definition.format === "uri") { try { new URL(current) } catch { throw invalid(location + " has an invalid format") } }
      if (definition.format === "ipv4" && !/^(?:0|[1-9]\d{0,2})(?:\.(?:0|[1-9]\d{0,2})){3}$/.test(current)) throw invalid(location + " has an invalid format")
      if (definition.format === "ipv6" && !current.includes(":")) throw invalid(location + " has an invalid format")
      if (definition.format === "hostname" && !/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/.test(current)) throw invalid(location + " has an invalid format")
      return current
    }
    if (definition["x-nelysia-kind"] === "bigint") {
      if (typeof current !== "bigint") throw invalid(location + " must be bigint")
      const option = (key) => typeof definition[key] === "string" && /^-?\d+$/.test(definition[key]) ? BigInt(definition[key]) : undefined
      const minimum = option("minimum")
      const maximum = option("maximum")
      const exclusiveMinimum = option("exclusiveMinimum")
      const exclusiveMaximum = option("exclusiveMaximum")
      const multipleOf = option("multipleOf")
      if (minimum !== undefined && current < minimum) throw invalid(location + " is below minimum")
      if (maximum !== undefined && current > maximum) throw invalid(location + " is above maximum")
      if (exclusiveMinimum !== undefined && current <= exclusiveMinimum) throw invalid(location + " is below exclusive minimum")
      if (exclusiveMaximum !== undefined && current >= exclusiveMaximum) throw invalid(location + " is above exclusive maximum")
      if (multipleOf !== undefined && current % multipleOf !== 0n) throw invalid(location + " must be a multiple of " + multipleOf)
      return current
    }
    if (definition.type === "number" || definition.type === "integer") {
      if (typeof current !== "number" || !Number.isFinite(current) || (definition.type === "integer" && !Number.isInteger(current))) throw invalid(location + " must be " + definition.type)
      if (typeof definition.minimum === "number" && current < definition.minimum) throw invalid(location + " is below minimum")
      if (typeof definition.maximum === "number" && current > definition.maximum) throw invalid(location + " is above maximum")
      if (typeof definition.exclusiveMinimum === "number" && current <= definition.exclusiveMinimum) throw invalid(location + " is below exclusive minimum")
      if (typeof definition.exclusiveMaximum === "number" && current >= definition.exclusiveMaximum) throw invalid(location + " is above exclusive maximum")
      if (typeof definition.multipleOf === "number" && definition.multipleOf > 0) { const quotient = current / definition.multipleOf; if (Math.abs(quotient - Math.round(quotient)) > Number.EPSILON * Math.max(1, Math.abs(quotient))) throw invalid(location + " must be a multiple of " + definition.multipleOf) }
      return current
    }
    if (definition.type === "boolean") { if (typeof current !== "boolean") throw invalid(location + " must be boolean"); return current }
    if (definition.type === "array") {
      if (!Array.isArray(current)) throw invalid(location + " must be array")
      if (typeof definition.minItems === "number" && current.length < definition.minItems) throw invalid(location + " has too few items")
      if (typeof definition.maxItems === "number" && current.length > definition.maxItems) throw invalid(location + " has too many items")
      if (definition.uniqueItems === true && new Set(current.map((entry) => JSON.stringify(entry) ?? String(entry))).size !== current.length) throw invalid(location + " must contain unique items")
      if (Array.isArray(definition.prefixItems)) {
        if (current.length !== definition.prefixItems.length) throw invalid(location + " has an invalid tuple length")
        return current.map((entry, index) => validate(entry, definition.prefixItems[index], location + "." + index))
      }
      return definition.items === undefined ? current : current.map((entry, index) => validate(entry, definition.items, location + "." + index))
    }
    if (definition.type === "object") {
      if (current === null || typeof current !== "object" || Array.isArray(current)) throw invalid(location + " must be object")
      const input = current
      const output = {}
      if (typeof definition.minProperties === "number" && Object.keys(input).length < definition.minProperties) throw invalid(location + " must have at least " + definition.minProperties + " properties")
      if (typeof definition.maxProperties === "number" && Object.keys(input).length > definition.maxProperties) throw invalid(location + " must have at most " + definition.maxProperties + " properties")
      for (const key of definition.required || []) if (input[key] === undefined) throw invalid(location + "." + key + " is required")
      const properties = definition.properties && typeof definition.properties === "object" && !Array.isArray(definition.properties) ? definition.properties : undefined
      const patterns = definition.patternProperties && typeof definition.patternProperties === "object" && !Array.isArray(definition.patternProperties) ? definition.patternProperties : undefined
      const patternFor = (key) => { for (const [pattern, child] of Object.entries(patterns || {})) { try { if (new RegExp(pattern).test(key)) return child } catch {} } }
      if (definition.additionalProperties === false) for (const key of Object.keys(input)) if ((!properties || !Object.prototype.hasOwnProperty.call(properties, key)) && !patternFor(key)) throw invalid(location + " must not contain additional properties")
      if (properties) for (const [key, child] of Object.entries(properties)) if (input[key] !== undefined) setSafe(output, key, validate(input[key], child, location + "." + key))
      for (const [key, entry] of Object.entries(input)) {
        if (properties && Object.prototype.hasOwnProperty.call(properties, key)) continue
        const pattern = patternFor(key)
        if (pattern) setSafe(output, key, validate(entry, pattern, location + "." + key))
        else if (definition.additionalProperties === true || patterns) setSafe(output, key, entry)
        else if (definition.additionalProperties && typeof definition.additionalProperties === "object") setSafe(output, key, validate(entry, definition.additionalProperties, location + "." + key))
      }
      return output
    }
    return current
  }
  return validate(value, schema, path)
}`;
}
function isStandaloneRoute(route) {
    if (route.auth !== undefined)
        return false;
    if (route.role !== undefined || route.permissions !== undefined || Object.keys(route.features ?? {}).length > 0 || (route.routeGuards?.length ?? 0) > 0)
        return false;
    const schemas = [route.bodySchema, route.paramsSchema, route.querySchema, route.headersSchema, route.responseSchema, ...Object.values(route.responseSchemas ?? {})];
    if (schemas.some((schema) => schema !== undefined && !canGenerateSchema(schema)))
        return false;
    if (route.staticValue !== undefined)
        return route.staticValue instanceof Response || route.staticValue instanceof ReadableStream ? false : serializeStaticValue(route.staticValue) !== undefined;
    const functions = [route.handler, ...(route.requestHooks ?? []), ...(route.parseHooks ?? []), ...route.hooks, ...(route.mapResponseHooks ?? []), ...route.afterHooks, ...(route.afterResponseHooks ?? []), ...route.errorHandlers, ...(route.routeGuards ?? [])];
    return functions.every(canEmbedFunction);
}
function functionSource(value) {
    const source = value.toString();
    if (source.startsWith("function") || source.startsWith("async function") || source.includes("=>"))
        return source;
    return `function ${source}`;
}
function canEmbedFunction(value) {
    try {
        const source = functionSource(value);
        new Function(`return (${source})`)();
        return !source.includes("[native code]") && hasOnlyEmbeddedIdentifiers(source);
    }
    catch {
        return false;
    }
}
function hasOnlyEmbeddedIdentifiers(source) {
    const sanitized = source
        .replace(/\/\*[\s\S]*?\*\//g, " ")
        .replace(/\/\/[^\n]*/g, " ")
        .replace(/'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|`(?:\\.|[^`\\])*`/g, " ");
    const bindings = new Set();
    const parameterEnd = sanitized.indexOf("=>");
    const parameterSource = parameterEnd === -1
        ? sanitized.slice(sanitized.indexOf("(") + 1, sanitized.indexOf(")"))
        : sanitized.slice(0, parameterEnd);
    for (const match of parameterSource.matchAll(/[A-Za-z_$][A-Za-z0-9_$]*/g))
        bindings.add(match[0]);
    for (const match of sanitized.matchAll(/\b(?:const|let|var|function|class|catch)\s+([A-Za-z_$][A-Za-z0-9_$]*)/g))
        bindings.add(match[1]);
    const allowed = new Set([
        "async", "await", "function", "return", "const", "let", "var", "if", "else", "for", "of", "in", "while", "do", "switch", "case", "break", "continue", "throw", "try", "catch", "finally", "new", "typeof", "void", "delete", "instanceof", "true", "false", "null", "undefined",
        "Math", "Date", "JSON", "Number", "String", "Boolean", "Object", "Array", "Promise", "RegExp", "Error", "URL", "URLSearchParams", "Headers", "Response", "Request", "TextEncoder", "TextDecoder", "Uint8Array", "ReadableStream", "Buffer", "crypto", "console"
    ]);
    for (const match of sanitized.matchAll(/[A-Za-z_$][A-Za-z0-9_$]*/g)) {
        const identifier = match[0];
        const index = match.index ?? 0;
        const before = sanitized.slice(0, index).trimEnd();
        const after = sanitized.slice(index + identifier.length).trimStart();
        if (before.endsWith(".") || (after.startsWith(":") && !after.startsWith("::")))
            continue;
        if (allowed.has(identifier) || bindings.has(identifier))
            continue;
        return false;
    }
    return true;
}
function literalSource(value) {
    if (value instanceof Uint8Array)
        return `new Uint8Array([${[...value].join(",")}])`;
    const serialized = JSON.stringify(value);
    if (serialized !== undefined)
        return serialized;
    return "undefined";
}
function compileDispatcherForManifest(compiled) {
    const routes = compiled.graph.routes;
    return { fast: routes.filter(isCompilableRoute).length, total: routes.length };
}
export function generateBuildArtifact(options) {
    const standalone = options.compiled.standaloneBlock === undefined && options.compiled.graph.routes.every(isStandaloneRoute);
    const dispatcher = compileDispatcherForManifest(options.compiled);
    const manifest = {
        version: 1,
        compiler: "nelysia",
        target: options.target,
        entry: options.entry,
        artifact: `server.${options.target}.ts`,
        sourceToSource: standalone,
        generation: standalone ? "standalone" : "adapter",
        dispatcher: !standalone,
        reproducible: true,
        cacheKey: "",
        sourceMap: `${`server.${options.target}.ts`}.map`,
        routes: options.compiled.analyses,
        diagnostics: [
            {
                code: "NELY001",
                severity: "info",
                message: standalone ? "This artifact is a standalone source-to-source server for the routes whose handlers and schemas can be embedded safely." : "This artifact retains the application entry and runtime adapter; routes that cannot be embedded safely use the generic fallback."
            },
            ...options.compiled.graph.routes
                .filter((route) => !isStandaloneRoute(route))
                .map((route) => {
                const analysis = options.compiled.analyses.find((item) => item.method === route.method && item.path === route.path);
                const unsupported = unsupportedRouteDiagnostic(route, analysis?.reason);
                return {
                    code: unsupported.code,
                    severity: "warning",
                    message: `Standalone generation unsupported: ${unsupported.reason}`,
                    route: { method: route.method, path: route.path },
                    field: unsupported.field
                };
            }),
            ...(options.compiled.standaloneBlock === undefined ? [] : [{
                    code: options.compiled.standaloneBlock.code,
                    severity: "warning",
                    message: `Standalone generation unsupported: ${options.compiled.standaloneBlock.reason}`
                }]),
            ...options.compiled.graph.routes
                .filter((route) => isCompilableRoute(route) && hasGeneratedSchema(route))
                .map((route) => ({
                code: "NELY002",
                severity: "info",
                message: "Generated validator/serializer fast path enabled for deterministic built-in schemas.",
                route: { method: route.method, path: route.path },
                field: "schema"
            })),
            ...(!standalone ? [{
                    code: "NELY003",
                    severity: "info",
                    message: `Compiled dispatcher fast path covers ${dispatcher.fast} of ${dispatcher.total} routes; ${dispatcher.total - dispatcher.fast} use the generic fallback.`,
                }] : [])
        ]
    };
    const source = generateStandaloneServerSource(options) ?? generateServerSource(options);
    const cacheKey = createHash("sha256").update(source).update(JSON.stringify(manifest)).digest("hex");
    const sourceMap = JSON.stringify({ version: 3, file: manifest.artifact, sourceRoot: "", sources: [options.entry], names: [], mappings: source.split("\n").map(() => "AAAA").join(";") });
    return { source, sourceMap, manifest: { ...manifest, reproducible: true, cacheKey } };
}
function hasGeneratedSchema(route) {
    return route.bodySchema !== undefined || route.paramsSchema !== undefined || route.querySchema !== undefined || route.headersSchema !== undefined || route.responseSchema !== undefined || Object.keys(route.responseSchemas ?? {}).length > 0;
}
/** Explain why a route cannot be emitted into the standalone artifact. The
 * first matching rule is intentionally deterministic so diagnostics remain
 * stable across builds and can be consumed by CI tooling. */
export function unsupportedRouteDiagnostic(route, analysisReason) {
    if (!"GET POST PUT PATCH DELETE OPTIONS HEAD".split(" ").includes(route.method))
        return { code: "NELY101", reason: `Unsupported method ${route.method}`, field: "method" };
    if ((route.requestHooks?.length ?? 0) > 0 || (route.parseHooks?.length ?? 0) > 0) {
        return { code: "NELY102", reason: "Request lifecycle hooks require the generic runtime", field: "lifecycle" };
    }
    if ((route.mapResponseHooks?.length ?? 0) > 0 || (route.afterResponseHooks?.length ?? 0) > 0 || route.afterHooks.length > 0) {
        return { code: "NELY103", reason: "Response lifecycle hooks require the generic runtime", field: "lifecycle" };
    }
    const schemas = [route.bodySchema, route.paramsSchema, route.querySchema, route.headersSchema, route.responseSchema, ...Object.values(route.responseSchemas ?? {})];
    if (schemas.some((schema) => schema !== undefined && !canGenerateSchema(schema))) {
        return { code: "NELY104", reason: "Schema validation requires the generic runtime", field: "schema" };
    }
    if (route.errorHandlers.length > 0)
        return { code: "NELY108", reason: "Native error handling requires the generic runtime", field: "error" };
    if (route.staticValue instanceof Response || route.staticValue instanceof ReadableStream)
        return { code: "NELY113", reason: "Static native values are not replay-safe in a standalone artifact", field: "handler" };
    if (route.hooks.length > 0)
        return { code: "NELY106", reason: "Context extensions or route hooks require the generic runtime", field: "lifecycle" };
    if (route.auth !== undefined)
        return { code: "NELY107", reason: "Mounted or authenticated route metadata requires the generic runtime", field: "auth" };
    if ((route.routeGuards?.length ?? 0) > 0 || route.role !== undefined || route.permissions !== undefined || Object.keys(route.features ?? {}).length > 0)
        return { code: "NELY107", reason: "Route guards and feature metadata require the runtime adapter", field: "features" };
    if (route.handler.toString().includes("ReadableStream"))
        return { code: "NELY109", reason: "Streaming responses require the generic runtime", field: "handler" };
    return { code: "NELY105", reason: analysisReason ?? "Opaque handler cannot be safely embedded into standalone source", field: "handler" };
}
//# sourceMappingURL=index.js.map