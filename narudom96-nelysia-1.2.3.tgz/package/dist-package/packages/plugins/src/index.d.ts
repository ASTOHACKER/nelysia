import { HttpError, type Nelysia } from "../../core/src/app.ts";
import type { Context } from "../../core/src/types.ts";
export interface RateLimitOptions {
    limit: number;
    windowMs: number;
    key?(context: Context): string;
}
export interface CompressionOptions {
    threshold?: number;
}
export interface StaticDirectoryOptions {
    prefix?: string;
    root: string | URL;
    index?: string;
}
export interface CorsOptions {
    origin?: string | string[] | boolean | ((origin: string, context: Context) => boolean | string);
    methods?: string | string[];
    allowedHeaders?: string | string[];
    exposedHeaders?: string | string[];
    credentials?: boolean;
    maxAge?: number;
}
export interface SecurityHeadersOptions {
    xContentTypeOptions?: boolean;
    xFrameOptions?: "DENY" | "SAMEORIGIN" | false;
    xXSSProtection?: boolean;
    referrerPolicy?: string | false;
    strictTransportSecurity?: string | false;
    crossOriginOpenerPolicy?: string | false;
    crossOriginResourcePolicy?: string | false;
}
export declare function rateLimit(options: RateLimitOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function staticFile(path: string, file: string | URL): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function staticDirectory(options: StaticDirectoryOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function compression(options?: CompressionOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function cors(options?: CorsOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function securityHeaders(options?: SecurityHeadersOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export { HttpError };
//# sourceMappingURL=index.d.ts.map