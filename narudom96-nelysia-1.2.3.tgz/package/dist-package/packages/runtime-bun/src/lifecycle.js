export async function closeBunServer(server) {
    server.stop(true);
}
//# sourceMappingURL=lifecycle.js.map