import type { Nelysia } from "../../core/src/app.ts";
export { createBunHandler } from "./handler.ts";
export interface BunServerOptions {
    hostname?: string;
}
export declare function createBunServer(app: Nelysia<any, any, any>, port: number, options?: BunServerOptions): unknown;
//# sourceMappingURL=server.d.ts.map