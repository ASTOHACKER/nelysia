export declare function closeBunServer(server: {
    stop(closeActiveConnections?: boolean): void;
}): Promise<void>;
//# sourceMappingURL=lifecycle.d.ts.map