import { type Nelysia } from "../../core/src/app.ts";
type BunHandler = (request: Request) => Response | Promise<Response>;
/**
 * Internal adapter boundary used by Bun. The core executor deliberately
 * returns a sync/async union; keeping that union through the adapter avoids a
 * Promise allocation for the common synchronous lifecycle path. The public
 * createBunHandler wrapper below retains its Promise-returning contract.
 */
export declare function createBunRuntimeHandler(app: Nelysia<any, any, any>): BunHandler;
/** Public Promise-returning compatibility wrapper. */
export declare function createBunHandler(app: Nelysia<any, any, any>): (request: Request) => Promise<Response>;
export declare function toResponse(result: {
    status: number;
    headers: Headers;
    body: unknown;
}): Response;
export {};
//# sourceMappingURL=handler.d.ts.map