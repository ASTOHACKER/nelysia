import { createCompiledBunHandler } from "../../compiler/src/index.js";
export { createBunHandler } from "./handler.js";
export function createBunServer(app, port, options = {}) {
    const runtime = globalThis;
    if (!runtime.Bun)
        throw new Error("Bun runtime is required");
    const hasWebSocket = app.websocketRoutes.length > 0;
    // Let the compiler build the fallback once as well. Keeping app.listen()
    // and the direct compiled entrypoint on the same handler construction avoids
    // an unnecessary extra closure on the public Bun boundary.
    const fetchHandler = createCompiledBunHandler(app);
    const websocketRoutes = new Map(app.websocketRoutes.map((route) => [route.path, route.handlers]));
    const fetch = hasWebSocket
        ? (request, server) => {
            if (request.headers.get("upgrade")?.toLowerCase() === "websocket") {
                const handlers = websocketRoutes.get(new URL(request.url).pathname);
                if (!handlers)
                    return new Response("Not Found", { status: 404 });
                return server.upgrade(request, { data: { handlers } })
                    ? undefined
                    : new Response("WebSocket upgrade failed", { status: 400 });
            }
            return fetchHandler(request);
        }
        : fetchHandler;
    const serveOptions = {
        port,
        ...(options.hostname === undefined ? {} : { hostname: options.hostname }),
        fetch
    };
    if (hasWebSocket)
        serveOptions.websocket = {
            async open(socket) { await socket.data.handlers.open?.(socket); },
            async message(socket, message) { await socket.data.handlers.message?.(socket, message); },
            async close(socket, code, reason) { await socket.data.handlers.close?.(socket, code, reason); },
            async error(socket, error) { await socket.data.handlers.error?.(socket, error); }
        };
    return runtime.Bun.serve(serveOptions);
}
//# sourceMappingURL=server.js.map