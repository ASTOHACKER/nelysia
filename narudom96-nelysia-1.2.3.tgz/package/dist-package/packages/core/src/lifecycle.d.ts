export interface ServerHandle {
    close?(callback?: (error?: Error) => void): void;
    closeIdleConnections?(): void;
    stop?(closeActiveConnections?: boolean): void | Promise<void>;
}
export declare function gracefulShutdown(server: ServerHandle, timeoutMs?: number): Promise<void>;
//# sourceMappingURL=lifecycle.d.ts.map