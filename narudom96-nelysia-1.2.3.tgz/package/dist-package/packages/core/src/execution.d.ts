import type { AfterHook, AfterResponseHook, ErrorHandler, Hook, MapResponseHook, RequestData, RequestPreflight, ResponseData, RouteRecord } from "./types.ts";
export type RuntimeLane = "minimal" | "specialized" | "generic";
export type ContextField = "request" | "requestId" | "clientIp" | "env" | "executionContext" | "params" | "query" | "set" | "store" | "body" | "headers" | "cookies" | "auth" | "route" | "signal" | "executionControl" | "logger" | "files" | "setCookie" | "deleteCookie" | "response" | "html" | "text" | "json" | "redirect" | "header";
export interface ContextNeeds {
    readonly full: boolean;
    /** Keep own-key semantics for handlers that explicitly enumerate context. */
    readonly ownProperties: boolean;
    readonly fields: readonly ContextField[];
    has(field: ContextField): boolean;
}
export interface ExecutionPlan {
    readonly lane: RuntimeLane;
    /** A full-context route can still use the precomputed stage runner when
     * no request/schema/provider stage needs the reference dispatcher. */
    readonly pipelineSafe: boolean;
    readonly contextFreePipeline: boolean;
    readonly needs: ContextNeeds;
    readonly handler: RouteRecord["handler"];
    readonly hooks: readonly Hook[];
    readonly nativeHooks: readonly Hook[];
    readonly afterHooks: readonly AfterHook[];
    readonly mapResponseHooks: readonly MapResponseHook[];
    readonly afterResponseHooks: readonly AfterResponseHook[];
    readonly errorHandlers: readonly ErrorHandler[];
    readonly allSynchronous: boolean;
}
export interface PreparedRequest {
    readonly request: RequestData;
    readonly route: RouteRecord;
    readonly params: Record<string, string>;
    readonly method: string;
    readonly pathname: string;
    readonly search: string;
    readonly plan: ExecutionPlan;
    readonly preflight?: Extract<RequestPreflight, {
        kind: "route";
    }>;
}
export interface RuntimeExecutor {
    preflight(request: RequestData): RequestPreflight | Promise<RequestPreflight>;
    handle(request: RequestData): ResponseData | Promise<ResponseData>;
    /** Native adapter lane for context-free routes; undefined delegates to handle. */
    handleNative?(request: RequestData): Response | Promise<Response> | undefined;
    /** Same lane without materializing RequestData for a native Web request. */
    handleNativeRequest?(request: Request, requestId?: string): Response | Promise<Response> | undefined;
}
export declare function registerRuntimeExecutor(app: object, executor: RuntimeExecutor): void;
export declare function getRuntimeExecutor(app: object): RuntimeExecutor | undefined;
export interface RuntimeComposition {
    readonly telemetry: boolean;
    readonly modulesPending: boolean;
    readonly mounts: boolean;
    readonly contextValues: boolean;
    readonly contextExtensions: boolean;
}
export interface ContextInference {
    readonly known: boolean;
    readonly fields: readonly ContextField[];
    readonly asynchronous: boolean;
    readonly ownProperties: boolean;
}
export declare function isDeclaredAsync(value: unknown): boolean;
export declare function isThenable(value: unknown): value is PromiseLike<unknown>;
export declare function inferContext(value: unknown, parameterIndex?: number): ContextInference;
export declare function createExecutionPlan(route: RouteRecord, composition: RuntimeComposition): ExecutionPlan;
//# sourceMappingURL=execution.d.ts.map