import { type SchemaIR, type SchemaIRNode, type SchemaReferenceRegistry } from "./schema-ir.ts";
export interface SchemaValidationOptions {
    readonly path?: string;
    readonly references?: SchemaReferenceRegistry;
    readonly maxDepth?: number;
}
export type SchemaFormatValidator = (value: string) => boolean;
export declare function registerSchemaFormat(name: string, validator: SchemaFormatValidator): void;
export declare function validateSchemaFormat(name: string, value: string): boolean;
export declare function validateSchema(value: unknown, ir: SchemaIR | SchemaIRNode, options?: SchemaValidationOptions): unknown;
export declare function validateSchemaAsync(value: unknown, ir: SchemaIR | SchemaIRNode, options?: SchemaValidationOptions): Promise<unknown>;
export declare function validateSchemaOptions(options: Record<string, unknown>, kind: string): void;
//# sourceMappingURL=schema-validator.d.ts.map