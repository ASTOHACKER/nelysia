import { HttpError } from "./types.js";
const compiledKinds = new Set([
    "any",
    "unknown",
    "never",
    "null",
    "boolean",
    "string",
    "number",
    "integer",
    "bigint",
    "date",
    "object",
    "array",
    "tuple",
    "record",
    "enum",
    "literal",
    "union",
    "intersect",
    "nullable",
    "optional",
    "template-literal",
]);
const referenceKinds = new Set(["standard", "ref"]);
/**
 * Normalize a public schema into the immutable representation shared by the
 * reference validator, compiler, and OpenAPI adapters.
 */
export function normalizeSchemaIR(schema) {
    const definitions = new Map();
    const root = normalizeNode(schema, definitions, new Set());
    const definitionRecord = {};
    for (const [id, node] of definitions)
        definitionRecord[id] = node;
    const result = {
        root,
        definitions: freezeValue(definitionRecord),
        capability: root.capability,
        hash: schemaIRHash(root),
    };
    return freezeValue(result);
}
export function schemaCapability(ir) {
    return "root" in ir ? ir.root.capability : ir.capability;
}
/** Return a normalized object-property child without exposing mutable schema internals. */
export function schemaIRChild(node, key) {
    const index = node.childKeys.indexOf(key);
    return index < 0 ? undefined : node.children[index];
}
export function resolveSchemaReference(id, registry) {
    const value = lookupReference(id, registry);
    if (!value)
        throw new HttpError(400, `Unknown schema reference: ${id}`);
    if (isSchemaIR(value))
        return value.root;
    if (isSchemaIRNode(value))
        return value;
    return normalizeSchemaIR(value).root;
}
export function schemaIRHash(ir) {
    const node = "root" in ir ? ir.root : ir;
    const serialized = stableSerialize(node);
    let hash = 2166136261;
    for (let index = 0; index < serialized.length; index++) {
        hash ^= serialized.charCodeAt(index);
        hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
}
function normalizeNode(schema, definitions, active) {
    if (active.has(schema)) {
        const definition = normalizeDefinition(schema.definition ?? { type: schema.kind });
        return freezeValue({
            kind: schema.kind,
            definition,
            children: [],
            childKeys: [],
            options: normalizeOptions(definition),
            capability: "reference",
            optional: schema.optional,
            id: readString(definition.$id),
            ref: readString(definition.$ref),
            additionalProperties: normalizeAdditionalSchema(schema, definitions, active),
        });
    }
    active.add(schema);
    const definition = normalizeDefinition(schema.definition ?? { type: schema.kind });
    const childInfo = getChildSchemas(schema);
    const children = childInfo.schemas.map((child) => normalizeNode(child, definitions, active));
    const additionalProperties = normalizeAdditionalSchema(schema, definitions, active);
    const node = freezeValue({
        kind: schema.kind,
        definition,
        children,
        childKeys: childInfo.keys,
        options: normalizeOptions(definition),
        capability: classifyCapability(schema.kind, definition, children, additionalProperties),
        optional: schema.optional,
        id: readString(definition.$id),
        ref: readString(definition.$ref),
        additionalProperties,
    });
    active.delete(schema);
    if (node.id)
        definitions.set(node.id, node);
    return node;
}
function getChildSchemas(schema) {
    const source = schema;
    if (source.shape && isRecord(source.shape)) {
        const keys = Object.keys(source.shape).sort();
        return { schemas: keys.map((key) => source.shape?.[key]).filter((child) => child !== undefined), keys };
    }
    if (source.items && Array.isArray(source.items))
        return { schemas: source.items, keys: [] };
    if (source.templateParts && Array.isArray(source.templateParts))
        return { schemas: source.templateParts.filter((part) => typeof part !== "string"), keys: [] };
    if (source.item)
        return { schemas: [source.item], keys: [] };
    if (source.inner)
        return { schemas: [source.inner], keys: [] };
    return { schemas: [], keys: [] };
}
function classifyCapability(kind, definition, children, additionalProperties) {
    if (kind === "standard" || referenceKinds.has(kind))
        return "reference";
    if (!compiledKinds.has(kind) || definition.$custom !== undefined)
        return "unsupported";
    if (children.some((child) => child.capability === "unsupported"))
        return "unsupported";
    if (children.some((child) => child.capability === "reference"))
        return "reference";
    if (additionalProperties && typeof additionalProperties === "object" && additionalProperties.capability === "unsupported")
        return "unsupported";
    if (additionalProperties && typeof additionalProperties === "object" && additionalProperties.capability === "reference")
        return "reference";
    return "compiled";
}
function normalizeAdditionalSchema(schema, definitions, active) {
    const additionalProperties = schema.additionalProperties;
    if (typeof additionalProperties === "boolean")
        return additionalProperties;
    if (additionalProperties && typeof additionalProperties === "object")
        return normalizeNode(additionalProperties, definitions, active);
    return undefined;
}
function normalizeDefinition(value) {
    return freezeValue(cloneJson(value));
}
function normalizeOptions(definition) {
    const options = {};
    for (const key of Object.keys(definition).sort())
        options[key] = definition[key];
    return freezeValue(options);
}
function cloneJson(value, active = new Set()) {
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean")
        return value;
    if (typeof value === "bigint")
        return { $type: "bigint", value: value.toString() };
    if (value instanceof Date)
        return value.toISOString();
    if (value instanceof RegExp)
        return { source: value.source, flags: value.flags };
    if (Array.isArray(value))
        return value.map((entry) => cloneJson(entry, active));
    if (typeof value !== "object")
        return String(value);
    if (active.has(value))
        return { $ref: "#cycle" };
    active.add(value);
    const output = {};
    for (const key of Object.keys(value).sort()) {
        output[key] = cloneJson(value[key], active);
    }
    active.delete(value);
    return output;
}
function stableSerialize(value) {
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean")
        return JSON.stringify(value);
    if (typeof value === "bigint")
        return `{"$bigint":${JSON.stringify(value.toString())}}`;
    if (Array.isArray(value))
        return `[${value.map(stableSerialize).join(",")}]`;
    if (typeof value === "object") {
        const record = value;
        return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableSerialize(record[key])}`).join(",")}}`;
    }
    return JSON.stringify(String(value));
}
function freezeValue(value, active = new Set()) {
    if (value === null || typeof value !== "object")
        return value;
    if (active.has(value))
        return value;
    active.add(value);
    if (Array.isArray(value)) {
        for (const entry of value)
            freezeValue(entry, active);
    }
    else {
        for (const entry of Object.values(value))
            freezeValue(entry, active);
    }
    active.delete(value);
    return Object.freeze(value);
}
function readString(value) {
    return typeof value === "string" ? value : undefined;
}
function lookupReference(id, registry) {
    const candidates = [id, id.replace(/^#\/(?:\$defs|components\/schemas)\//, "")];
    for (const candidate of candidates) {
        const value = registry instanceof Map ? registry.get(candidate) : registry[candidate];
        if (value !== undefined)
            return value;
    }
    return undefined;
}
function isSchemaIR(value) {
    return typeof value === "object" && value !== null && "root" in value && "hash" in value;
}
function isSchemaIRNode(value) {
    return typeof value === "object" && value !== null && "children" in value && "capability" in value;
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
//# sourceMappingURL=schema-ir.js.map