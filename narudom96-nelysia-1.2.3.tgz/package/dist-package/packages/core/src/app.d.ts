import { type Schema, type StandardSchema } from "./schema.ts";
import { HttpError, type AddRoute, type AfterHook, type AfterResponseHook, type ApplyGuard, type AuthStrategyProvider, type Context, type DecorationOptions, type ErrorHandler, type FetchHandler, type GuardOptions, type Handler, type Hook, type HookOptions, type InjectOptions, type InjectResponse, type InjectResponseBodyFor, type InjectResponseStatusesFor, type MacroDefinition, type MapResponseHook, type MergeRouteMaps, type ModelValues, type ModuleGraphNode, type NelysiaOptions, type NelysiaPlugin, type ParseHook, type ParsedQuery, type RequestData, type RequestHook, type ResponseData, type ResponseOptions, type RouteContext, type RouteFeatureProvider, type RouteGraph, type RouteGuard, type RouteMap, type RouteOptions, type RouteRecord, type ServerInfo, type Telemetry, type TransformHook, type TypedInjectOptions, type WebSocketHandlers } from "./types.ts";
import { type ExecutionLane } from "../../compiler/src/dispatcher.ts";
type PluginCallback = (app: Nelysia<any, any, any>) => Nelysia<any, any, any> | void | Promise<Nelysia<any, any, any> | void>;
type StartupHook = (info: ServerInfo) => void | Promise<void>;
type Plugin = Nelysia<any, any, any> | PluginCallback | NelysiaPlugin<any>;
type LazyPlugin = Plugin | Promise<Plugin | {
    default?: Plugin;
    app?: Plugin;
}>;
type ExtensionsOf<App> = App extends Nelysia<infer Extensions, any, any> ? Extensions : {};
type RoutesOf<App> = App extends Nelysia<any, infer Routes, any> ? Routes : {};
type ModelsOf<App> = App extends Nelysia<any, any, infer Models> ? Models : {};
type MacrosOf<App> = App extends Nelysia<any, any, any, infer Macros> ? Macros : never;
type MergeMacroNames<Left extends string, Right extends string> = Left | Right;
type PrefixRoutes<Prefix extends string, Routes extends RouteMap> = {
    [Key in keyof Routes as Key extends `${infer Method} ${infer Path}` ? `${Method} ${JoinRoutePath<Prefix, Path>}` : never]: Routes[Key];
};
type TrimLeftSlash<Value extends string> = Value extends `/${infer Rest}` ? TrimLeftSlash<Rest> : Value;
type TrimRightSlash<Value extends string> = Value extends `${infer Rest}/` ? TrimRightSlash<Rest> : Value;
type CleanPrefix<Value extends string> = TrimLeftSlash<TrimRightSlash<Value>>;
type JoinRoutePath<Prefix extends string, Path extends string> = Prefix extends "/" ? Path : Path extends "/" ? `/${CleanPrefix<Prefix>}` : `/${CleanPrefix<Prefix>}/${TrimLeftSlash<Path>}`;
type AddAllRoutes<Routes extends RouteMap, Path extends string, Options extends object, Result> = AddRoute<AddRoute<AddRoute<AddRoute<AddRoute<AddRoute<AddRoute<Routes, "GET", Path, Options, Result>, "POST", Path, Options, Result>, "PUT", Path, Options, Result>, "PATCH", Path, Options, Result>, "DELETE", Path, Options, Result>, "OPTIONS", Path, Options, Result>, "HEAD", Path, Options, Result>;
export declare class Nelysia<Extensions extends Record<string, unknown> = {}, Routes extends RouteMap = {}, Models extends Record<string, unknown> = {}, MacroNames extends string = never> {
    /** Type-only route map bridge used by the standalone client package. */
    readonly __nelysiaRouteMap?: Routes;
    readonly graph: RouteGraph;
    readonly prefix: string;
    readonly name?: string;
    readonly seed?: unknown;
    readonly bodyLimit: number;
    private readonly routeOptions;
    private readonly trustedProxy;
    private readonly secureCookies;
    private hooks;
    private localHooks;
    private requestHooks;
    private localRequestHooks;
    private scopedRequestHooks;
    private globalRequestHooks;
    private parseHooks;
    private localParseHooks;
    private scopedParseHooks;
    private globalParseHooks;
    private transformHooks;
    private localTransformHooks;
    private scopedTransformHooks;
    private globalTransformHooks;
    private mapResponseHooks;
    private localMapResponseHooks;
    private scopedMapResponseHooks;
    private globalMapResponseHooks;
    private afterResponseHooks;
    private localAfterResponseHooks;
    private scopedAfterResponseHooks;
    private globalAfterResponseHooks;
    private scopedHooks;
    private globalHooks;
    private afterHooks;
    private localAfterHooks;
    private scopedAfterHooks;
    private globalAfterHooks;
    private errorHandlers;
    private localErrorHandlers;
    private scopedErrorHandlers;
    private globalErrorHandlers;
    private readonly contextValues;
    private readonly stateValues;
    private readonly decorationValues;
    private readonly nonEnumerableDecorations;
    private readonly lazyDecorations;
    private readonly models;
    private readonly macros;
    private contextExtensionHooks;
    private readonly usedPlugins;
    private readonly namedPlugins;
    private readonly moduleDependencies;
    private readonly modulePromises;
    private readonly startHooks;
    private moduleCompletion?;
    private moduleState;
    private moduleLoadError?;
    readonly telemetry?: Telemetry;
    readonly websocketRoutes: {
        path: string;
        handlers: WebSocketHandlers;
    }[];
    private readonly fetchMounts;
    private readonly staticRoutes;
    private readonly staticGetRoutes;
    private readonly dynamicRoutes;
    /** Route plans are private composition-time snapshots. The version lets a
     * mutation invalidate every route without adding state to public
     * RouteRecord values. */
    private executionPlanVersion;
    private readonly executionPlanCache;
    private readonly mountedRoutes;
    private readonly routeGuardRegistrations;
    private readonly authStrategyProviders;
    private readonly routeFeatureProviders;
    /** Non-fatal configuration findings retained for `nelysia doctor`. */
    private readonly configurationDiagnostics;
    private readonly appliedRouteFeatures;
    private readonly routeFeatureHooks;
    private readonly appliedAuthorization;
    private readonly routeAuthorizationHooks;
    /** Public so runtime adapters can skip UUID generation when disabled. */
    readonly requestIdEnabled: boolean;
    private notFoundHandler?;
    constructor(options?: NelysiaOptions);
    private invalidateExecutionPlans;
    /** Internal extension point for route-scoped guards such as JWT auth. */
    registerRouteGuard(guard: RouteGuard, applies: (auth: RouteRecord["auth"]) => boolean): this;
    /** Register an authentication provider without wrapping handlers. Providers
     * are matched after routing and before parsing/validation. */
    registerAuthStrategy(name: string, provider: AuthStrategyProvider): this;
    /** Register a lazy route feature implementation. A route must declare the
     * feature after its provider is installed; no feature is auto-enabled. */
    registerRouteFeature<Value = unknown>(name: string, provider: RouteFeatureProvider<Value>): this;
    private routeGuardsFor;
    private normalizeAuthSetting;
    private applyRouteFeature;
    private applyRouteFeatures;
    private applyRouteAuthorization;
    private inheritProviders;
    onBeforeHandle(hook: Hook): this;
    onBeforeHandle(options: HookOptions, hook: Hook): this;
    onRequest(hook: RequestHook): this;
    onRequest(options: HookOptions, hook: RequestHook): this;
    onParse(hook: ParseHook): this;
    onParse(options: HookOptions, hook: ParseHook): this;
    onTransform(hook: TransformHook): this;
    onTransform(options: HookOptions, hook: TransformHook): this;
    mapResponse(hook: MapResponseHook): this;
    mapResponse(options: HookOptions, hook: MapResponseHook): this;
    onAfterResponse(hook: AfterResponseHook): this;
    onAfterResponse(options: HookOptions, hook: AfterResponseHook): this;
    as(scope: HookOptions["as"]): this;
    onAfterHandle(hook: AfterHook): this;
    onAfterHandle(options: HookOptions, hook: AfterHook): this;
    onError(handler: ErrorHandler): this;
    onError(options: HookOptions, handler: ErrorHandler): this;
    onStart(hook: StartupHook): this;
    routeDiagnostics(): Array<{
        method: string;
        path: string;
        lane: ExecutionLane;
    }>;
    state<K extends string, Value>(name: K, value: Value): Nelysia<Extensions & {
        store: Record<K, Value>;
    } & Record<K, Value>, Routes, Models, MacroNames>;
    decorate<K extends string, Value>(name: K, value: Value | ((context: Context & Extensions) => Value), options?: DecorationOptions): Nelysia<Extensions & Record<K, Value>, Routes, Models, MacroNames>;
    derive<Added extends Record<string, unknown>>(extension: (context: Context & Extensions) => Added | void | Promise<Added | void>): Nelysia<Extensions & Added, Routes, Models, MacroNames>;
    resolve<Added extends Record<string, unknown>>(extension: (context: Context & Extensions) => Added | void | Promise<Added | void>): Nelysia<Extensions & Added, Routes, Models, MacroNames>;
    macro<Definitions extends Record<string, MacroDefinition>>(definitions: Definitions): Nelysia<Extensions, Routes, Models, MergeMacroNames<MacroNames, Extract<keyof Definitions, string>>>;
    model<Definitions extends Record<string, Schema | StandardSchema>>(models: Definitions): Nelysia<Extensions, Routes, Models & ModelValues<Definitions>, MacroNames>;
    guard<Guard extends GuardOptions<Models>, Child extends Nelysia<any, any, any, any>>(options: Guard, callback: (app: Nelysia<Extensions, Routes, Models, MacroNames>) => Child): Nelysia<Extensions, MergeRouteMaps<Routes, ApplyGuard<RoutesOf<Child>, Guard, Models>>, Models & ModelsOf<Child>, MergeMacroNames<MacroNames, MacrosOf<Child>>>;
    guard(options: GuardOptions<Models>, callback: (app: Nelysia<Extensions, Routes, Models, MacroNames>) => void): this;
    notFound(handler: Handler): this;
    use<PluginApp extends Nelysia<any, any, any, any>>(plugin: PluginApp): Nelysia<Extensions & ExtensionsOf<PluginApp>, MergeRouteMaps<Routes, RoutesOf<PluginApp>>, Models & ModelsOf<PluginApp>, MergeMacroNames<MacroNames, MacrosOf<PluginApp>>>;
    use<PluginApp extends Nelysia<any, any, any, any>>(plugin: Promise<PluginApp>): Nelysia<Extensions & ExtensionsOf<PluginApp>, MergeRouteMaps<Routes, RoutesOf<PluginApp>>, Models & ModelsOf<PluginApp>, MergeMacroNames<MacroNames, MacrosOf<PluginApp>>>;
    use<Added extends object>(plugin: NelysiaPlugin<Added>): Nelysia<Extensions & Added, Routes, Models, MacroNames>;
    use<PluginApp extends Nelysia<any, any, any, any>>(plugin: (app: Nelysia<Extensions, Routes, Models, MacroNames>) => PluginApp): Nelysia<Extensions & ExtensionsOf<PluginApp>, MergeRouteMaps<Routes, RoutesOf<PluginApp>>, Models & ModelsOf<PluginApp>, MergeMacroNames<MacroNames, MacrosOf<PluginApp>>>;
    use(plugin: LazyPlugin): this;
    /** Explicit lazy-plugin spelling. `.use(Promise)` remains supported for v0.x compatibility. */
    lazy(loader: () => LazyPlugin): this;
    lazy<PluginApp extends Nelysia<any, any, any, any>>(loader: () => PluginApp | Promise<PluginApp>): Nelysia<Extensions & ExtensionsOf<PluginApp>, MergeRouteMaps<Routes, RoutesOf<PluginApp>>, Models & ModelsOf<PluginApp>, MergeMacroNames<MacroNames, MacrosOf<PluginApp>>>;
    /** Explicit lazy sub-application spelling with a prefix. */
    mountLazy<Prefix extends string, PluginApp extends Nelysia<any, any, any, any>>(prefix: Prefix, loader: () => PluginApp | Promise<PluginApp>): Nelysia<Extensions, MergeRouteMaps<Routes, PrefixRoutes<Prefix, RoutesOf<PluginApp>>>, Models & ModelsOf<PluginApp>, MergeMacroNames<MacroNames, MacrosOf<PluginApp>>>;
    mountLazy(prefix: string, loader: () => Nelysia<any, any, any> | FetchHandler | Promise<Nelysia<any, any, any> | FetchHandler>): this;
    get modules(): Promise<void>;
    get moduleGraph(): ModuleGraphNode;
    get hasGlobalLifecycle(): boolean;
    get hasFetchMounts(): boolean;
    get usesTrustedProxy(): boolean;
    get usesSecureCookies(): boolean;
    get hasCustomNotFound(): boolean;
    get modelDefinitions(): ReadonlyMap<string, Schema | StandardSchema>;
    /** True when per-request state/decorations must be present for contextful handlers. */
    get hasContextValues(): boolean;
    get<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddRoute<Routes, "GET", Path, Options, Result, Models>, Models, MacroNames>;
    get<Path extends string, Value>(path: Path, body: Value, options?: RouteOptions<Models, MacroNames>): Nelysia<Extensions, AddRoute<Routes, "GET", Path, RouteOptions<Models, MacroNames>, Value, Models>, Models, MacroNames>;
    getStatic(path: string, body: unknown): this;
    post<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddRoute<Routes, "POST", Path, Options, Result, Models>, Models, MacroNames>;
    put<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddRoute<Routes, "PUT", Path, Options, Result, Models>, Models, MacroNames>;
    patch<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddRoute<Routes, "PATCH", Path, Options, Result, Models>, Models, MacroNames>;
    delete<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddRoute<Routes, "DELETE", Path, Options, Result, Models>, Models, MacroNames>;
    head<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddRoute<Routes, "HEAD", Path, Options, Result, Models>, Models, MacroNames>;
    options<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddRoute<Routes, "OPTIONS", Path, Options, Result, Models>, Models, MacroNames>;
    all<Path extends string, Options extends RouteOptions<Models, MacroNames> = RouteOptions<Models, MacroNames>, Result = unknown>(path: Path, handler: (context: RouteContext<Extensions, Options, Models>) => Result | Promise<Result>, options?: Options): Nelysia<Extensions, AddAllRoutes<Routes, Path, Options, Result>, Models, MacroNames>;
    websocket(path: string, handlers: WebSocketHandlers): this;
    mount<Prefix extends string, Child extends Nelysia<any, any, any, any>>(prefix: Prefix, child: Child): Nelysia<Extensions, MergeRouteMaps<Routes, PrefixRoutes<Prefix, RoutesOf<Child>>>, Models & ModelsOf<Child>, MergeMacroNames<MacroNames, MacrosOf<Child>>>;
    mount(prefix: string, handler: FetchHandler): this;
    group<Prefix extends string, Child extends Nelysia<any, any, any, any>>(prefix: Prefix, callback: (app: Nelysia<Extensions, Routes, Models, MacroNames>) => Child): Nelysia<Extensions, MergeRouteMaps<Routes, PrefixRoutes<Prefix, RoutesOf<Child>>>, Models & ModelsOf<Child>, MergeMacroNames<MacroNames, MacrosOf<Child>>>;
    group(prefix: string, callback: (app: Nelysia<Extensions, Routes, Models, MacroNames>) => void): this;
    group<Prefix extends string, Guard extends GuardOptions<Models>, Child extends Nelysia<any, any, any, any>>(prefix: Prefix, options: Guard, callback: (app: Nelysia<Extensions, Routes, Models, MacroNames>) => Child): Nelysia<Extensions, MergeRouteMaps<Routes, PrefixRoutes<Prefix, ApplyGuard<RoutesOf<Child>, Guard, Models>>>, Models & ModelsOf<Child>, MergeMacroNames<MacroNames, MacrosOf<Child>>>;
    group(prefix: string, options: GuardOptions<Models>, callback: (app: Nelysia<Extensions, Routes, Models, MacroNames>) => void): this;
    listen(port: number | {
        port: number;
        hostname?: string;
    }, callback?: (info: ServerInfo) => void): unknown;
    private runStartHooks;
    inject<Options extends TypedInjectOptions<Routes> = TypedInjectOptions<Routes>>(options?: Options): Promise<InjectResponse<InjectResponseBodyFor<Routes, Options>, InjectResponseStatusesFor<Routes, Options>>>;
    /** Explicit route-map aware alias for callers that want path-specific
     * response inference at the call site. */
    injectTyped<Options extends TypedInjectOptions<Routes>>(options: Options): Promise<InjectResponse<InjectResponseBodyFor<Routes, Options>, InjectResponseStatusesFor<Routes, Options>>>;
    /** Escape hatch for tests and callers that intentionally do not use the
     * route map, while keeping `inject()` strict for typed applications. */
    injectUntyped(options?: InjectOptions): Promise<InjectResponse>;
    route(method: string, path: string, handler: Handler<any>, options?: RouteOptions<Models, MacroNames>): this;
    private registerRoute;
    private routesForScope;
    /**
     * Build one immutable plan per route composition. A route record is still
     * the public source of truth; the plan is deliberately kept out of it.
     */
    private executionPlan;
    private canUseMinimalContext;
    /**
     * Serve a minimal-context route: invoke the handler with nothing (zero-arg)
     * or a bare `{ params }` object and wrap the result exactly like the
     * generic lane does for hook-free routes (no set.status/headers to merge,
     * no schemas to validate, no hooks to run). The x-request-id response
     * contract matches createContext: echoed/generated when enabled.
     */
    private handleMinimalContext;
    /**
     * Opaque handlers still receive the complete Context contract, but the
     * expensive query/store/cookie/helper values are inherited accessors and
     * only materialize when the handler reads them. Handlers that inspect own
     * keys are kept on the eager literal path by ExecutionPlan.
     */
    private createLazyFullContext;
    private createContext;
    private addContextExtension;
    private describeModule;
    private waitForModules;
    /**
     * Adapter preflight: match the route and run request hooks/guards before an
     * adapter consumes a request body. The returned context is reused by
     * handle(), which preserves auth data set by a guard.
     */
    preflight(request: RequestData): Promise<import("./types.ts").RequestPreflight>;
    private runPreflight;
    private preflightReference;
    private dependsOn;
    private resolveSchema;
    private resolveResponseSchemas;
    private applyGuard;
    handle(request: RequestData): Promise<ResponseData>;
    private runNativeHandle;
    private runNativeMatch;
    private runNativePrepared;
    private toNativeResponse;
    private handleContextFreeNative;
    private runContextFreeNative;
    private finishContextFreeNative;
    private nativeResponseData;
    private nativeBodyResponse;
    private runHandle;
    private runPrepared;
    private handleContextFreePipeline;
    private runContextFreeSynchronous;
    private runContextFreeWithClosures;
    private finishContextFree;
    private finishContextFreeError;
    private finishContextFreeNativeError;
    private prepareRuntimeRequest;
    private handleSpecialized;
    /**
     * Small synchronous generic lane for opaque handlers with no lifecycle
     * stages left to run. The handler still receives the full context, but the
     * common path avoids allocating the closure graph used by the reference
     * async-compatible runner. Thenables are checked at the invocation boundary
     * so a sync-classified handler that returns a Promise keeps its semantics.
     */
    private handleSpecializedSynchronous;
    private finishSpecializedSynchronous;
    private finishSpecializedSynchronousError;
    private handleSpecializedNativeSynchronous;
    private finishSpecializedNativeSynchronous;
    private finishSpecializedNativeSynchronousError;
    private handleReference;
    /** Adapter boundary for failures that occur before `handle()` can receive a
     * parsed body (for example malformed JSON or a body-limit rejection). */
    handleAdapterError(error: unknown, request: RequestData): Promise<ResponseData>;
    response(body: unknown, options?: ResponseOptions): ResponseData;
    response(status: number, body: unknown, headers?: Record<string, string>): ResponseData;
    private exportTelemetrySpan;
    private telemetryDuration;
    private emitTelemetryEvent;
}
export { HttpError };
export declare function createParsedQuery(search: string): ParsedQuery;
export declare function asParsedQuery(source: unknown): ParsedQuery;
//# sourceMappingURL=app.d.ts.map