export const responseMarker = Symbol("nelysia.response");
export function requestIdFor(request) {
    return request.requestId ?? request.headers?.get("x-request-id") ?? `req-${request.method}-${request.url}`;
}
export class HttpError extends Error {
    status;
    body;
    constructor(status, message, body) {
        super(message);
        this.status = status;
        this.body = body;
    }
}
export function error(status, body) {
    const message = typeof body === "string" ? body : `HTTP ${status}`;
    return new HttpError(status, message, body);
}
//# sourceMappingURL=types.js.map