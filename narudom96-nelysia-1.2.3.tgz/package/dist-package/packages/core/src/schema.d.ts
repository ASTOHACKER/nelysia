export interface Schema<T = unknown> {
    readonly kind: string;
    readonly optional?: boolean;
    validate(value: unknown, path?: string): T | Promise<T>;
    readonly definition?: Record<string, unknown>;
    readonly shape?: Readonly<Record<string, Schema>>;
    readonly item?: Schema;
    readonly key?: Schema;
    readonly items?: readonly Schema[];
    readonly inner?: Schema;
    readonly templateParts?: readonly (string | Schema)[];
    readonly additionalProperties?: boolean | Schema;
}
export interface StandardSchema<T = unknown> {
    readonly "~standard": {
        readonly version: 1;
        readonly validate: (value: unknown) => T | {
            value: T;
        } | Promise<T | {
            value: T;
        } | {
            issues: readonly {
                message: string;
                path?: readonly (string | number)[];
            }[];
        }> | {
            issues: readonly {
                message: string;
                path?: readonly (string | number)[];
            }[];
        };
    };
}
export interface SchemaOptions {
    readonly [key: string]: unknown;
    readonly $schema?: string;
    readonly $id?: string;
    readonly title?: string;
    readonly description?: string;
    readonly default?: unknown;
    readonly examples?: unknown;
    readonly readOnly?: boolean;
    readonly writeOnly?: boolean;
}
export interface NumberOptions extends SchemaOptions {
    readonly exclusiveMaximum?: number;
    readonly exclusiveMinimum?: number;
    readonly maximum?: number;
    readonly minimum?: number;
    readonly multipleOf?: number;
}
export interface StringOptions extends SchemaOptions {
    readonly format?: string;
    readonly minLength?: number;
    readonly maxLength?: number;
    readonly pattern?: string | RegExp;
}
export interface ObjectOptions extends SchemaOptions {
    readonly additionalProperties?: boolean | Schema;
    readonly maxProperties?: number;
    readonly minProperties?: number;
}
export interface ArrayOptions extends SchemaOptions {
    readonly maxItems?: number;
    readonly minItems?: number;
    readonly uniqueItems?: boolean;
}
export interface BigIntOptions extends SchemaOptions {
    readonly exclusiveMaximum?: bigint;
    readonly exclusiveMinimum?: bigint;
    readonly maximum?: bigint;
    readonly minimum?: bigint;
    readonly multipleOf?: bigint;
}
export interface TupleOptions extends SchemaOptions {
    readonly maxItems?: number;
    readonly minItems?: number;
}
export interface RecordOptions extends SchemaOptions {
    readonly maxProperties?: number;
    readonly minProperties?: number;
}
export interface TemplateLiteralOptions extends StringOptions {
}
export type Infer<S extends Schema> = S extends Schema<infer T> ? T : never;
type UnionToIntersection<Value> = (Value extends unknown ? (argument: Value) => void : never) extends ((argument: infer Intersection) => void) ? Intersection : never;
type ShapeInfer<Shape extends Record<string, Schema>> = {
    [K in keyof Shape as Shape[K]["optional"] extends true ? never : K]: Infer<Shape[K]>;
} & {
    [K in keyof Shape as Shape[K]["optional"] extends true ? K : never]?: Infer<Shape[K]>;
};
type ObjectSchema<Shape extends Record<string, Schema>> = Schema<ShapeInfer<Shape>> & {
    readonly shape: Shape;
    readonly additionalProperties?: boolean | Schema;
};
type TupleInfer<Items extends readonly Schema[]> = {
    -readonly [K in keyof Items]: Infer<Items[K]>;
};
type RemoveOptional<SchemaType extends Schema> = Schema<Exclude<Infer<SchemaType>, undefined>>;
type RequiredShape<Shape extends Record<string, Schema>> = {
    [K in keyof Shape]: RemoveOptional<Shape[K]>;
};
type CompositeInfer<Items extends readonly Schema[]> = UnionToIntersection<Infer<Items[number]>>;
type EnumInput = readonly (string | number)[] | Readonly<Record<string, string | number>>;
type EnumInfer<Input extends EnumInput> = Input extends readonly (infer Value)[] ? Extract<Value, string | number> : Input extends Readonly<Record<string, infer Value>> ? Extract<Value, string | number> : never;
type RecordKeyInfer<Key extends Schema> = Extract<Infer<Key>, string | number>;
type RecordOutput<Key extends Schema, Item extends Schema> = Schema<Record<RecordKeyInfer<Key>, Infer<Item>>> & {
    readonly key: Key;
    readonly item: Item;
};
declare function createRecord<Item extends Schema>(item: Item, options?: RecordOptions): Schema<Record<string, Infer<Item>>> & {
    readonly item: Item;
};
declare function createRecord<Key extends Schema, Item extends Schema>(key: Key, item: Item, options?: RecordOptions): RecordOutput<Key, Item>;
declare function createComposite<Items extends readonly ObjectSchema<any>[]>(items: Items, options?: ObjectOptions): Schema<CompositeInfer<Items>>;
declare function createComposite<Left extends ObjectSchema<any>, Right extends ObjectSchema<any>>(left: Left, right: Right): Schema<Infer<Left> & Infer<Right>>;
export declare const t: {
    String: (options?: StringOptions) => Schema<string>;
    Number: (options?: NumberOptions) => Schema<number>;
    Integer: (options?: NumberOptions) => Schema<number>;
    Boolean: (options?: SchemaOptions) => Schema<boolean>;
    BigInt: (options?: BigIntOptions) => Schema<bigint>;
    Null: (options?: SchemaOptions) => Schema<null>;
    Never: (options?: SchemaOptions) => Schema<never>;
    Ref: (id: string, options?: SchemaOptions) => Schema<unknown>;
    Cyclic: <T extends Schema>(builder: (self: Schema) => T, options?: SchemaOptions) => T;
    Object: <Shape extends Record<string, Schema>>(shape: Shape, options?: ObjectOptions) => ObjectSchema<Shape>;
    Array: <Item extends Schema>(item: Item, options?: ArrayOptions) => Schema<Infer<Item>[]> & {
        readonly item: Item;
    };
    Tuple: <Items extends readonly Schema[]>(items: Items, options?: TupleOptions) => Schema<TupleInfer<Items>> & {
        readonly items: Items;
    };
    Literal: <T extends string | number | boolean | null>(value: T, options?: SchemaOptions) => Schema<T>;
    Union: <Items extends readonly Schema[]>(items: Items, options?: SchemaOptions) => Schema<Infer<Items[number]>> & {
        readonly items: Items;
    };
    Nullable: <Item extends Schema>(item: Item, options?: SchemaOptions) => Schema<Infer<Item> | null> & {
        readonly inner: Item;
    };
    Optional: <Item extends Schema>(item: Item, options?: SchemaOptions) => Schema<Infer<Item> | undefined> & {
        readonly optional: true;
        readonly inner: Item;
    };
    Any: (options?: SchemaOptions) => Schema<unknown>;
    Unknown: (options?: SchemaOptions) => Schema<unknown>;
    Date: (options?: SchemaOptions) => Schema<Date>;
    TemplateLiteral: <Parts extends readonly (string | Schema)[]>(parts: Parts | string, options?: TemplateLiteralOptions) => Schema<string> & {
        readonly templateParts: Parts | readonly (string | Schema)[];
    };
    Partial: <Shape extends Record<string, Schema>>(schema: ObjectSchema<Shape>, options?: ObjectOptions) => Schema<Partial<ShapeInfer<Shape>>>;
    Pick: <Shape extends Record<string, Schema>, Keys extends readonly (keyof Shape)[]>(schema: ObjectSchema<Shape>, keys: Keys, options?: ObjectOptions) => Schema<Pick<ShapeInfer<Shape>, Extract<Keys[number], keyof ShapeInfer<Shape>>>>;
    Omit: <Shape extends Record<string, Schema>, Keys extends readonly (keyof Shape)[]>(schema: ObjectSchema<Shape>, keys: Keys, options?: ObjectOptions) => Schema<Omit<ShapeInfer<Shape>, Extract<Keys[number], keyof ShapeInfer<Shape>>>>;
    Intersect: <Items extends readonly Schema[]>(items: Items, options?: SchemaOptions) => Schema<UnionToIntersection<Infer<Items[number]>>> & {
        readonly items: Items;
    };
    Enum: <Input extends EnumInput>(values: Input, options?: SchemaOptions) => Schema<EnumInfer<Input>>;
    Record: typeof createRecord;
    Required: <Shape extends Record<string, Schema>>(schema: ObjectSchema<Shape>, options?: ObjectOptions) => ObjectSchema<RequiredShape<Shape>>;
    Readonly: <Shape extends Record<string, Schema>>(schema: ObjectSchema<Shape>, options?: ObjectOptions) => Schema<Readonly<ShapeInfer<Shape>>>;
    Composite: typeof createComposite;
};
export declare function fromStandardSchema<T>(schema: StandardSchema<T>): Schema<T>;
export {};
//# sourceMappingURL=schema.d.ts.map