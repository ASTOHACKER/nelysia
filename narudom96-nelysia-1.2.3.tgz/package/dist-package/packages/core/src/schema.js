import { HttpError } from "./types.js";
import { validateSchemaOptions } from "./schema-validator.js";
import { normalizeSchemaIR } from "./schema-ir.js";
import { validateSchema, validateSchemaAsync } from "./schema-validator.js";
let cyclicSchemaId = 0;
const primitive = (kind, check, options = {}) => {
    validateSchemaOptions(options, kind);
    const schema = {
        kind,
        definition: schemaDefinition(kind, options),
        validate(value, path = "body") {
            if (!check(value))
                throw new HttpError(400, `${path} must be ${kind}`);
            return validateSchema(value, normalized, { path });
        }
    };
    const normalized = normalizeSchemaIR(schema);
    return schema;
};
function runtimeSchema(schema) {
    let normalized;
    const result = {
        ...schema,
        validate(value, path = "body") {
            return validateSchema(value, normalized, { path });
        }
    };
    normalized = normalizeSchemaIR(result);
    return result;
}
function schemaWithOptions(definition, options) {
    const output = { ...definition };
    applySchemaOptions(output, options);
    return output;
}
function createRecord(first, second, third = {}) {
    const keyed = isSchemaValue(second);
    const key = keyed ? first : undefined;
    const item = (keyed ? second : first);
    const options = (keyed ? third : second ?? {});
    validateSchemaOptions(options, "record");
    const literalKeys = key ? recordLiteralKeys(key) : undefined;
    if (literalKeys && literalKeys.length > 0) {
        const shape = Object.fromEntries(literalKeys.map((value) => [String(value), item]));
        const object = t.Object(shape, options);
        return { ...object, key, item };
    }
    const valueDefinition = item.definition ?? { type: item.kind };
    const keyPattern = key ? recordKeyPattern(key) : undefined;
    const definition = {
        ...schemaDefinition("object", options),
        ...(keyPattern ? { patternProperties: { [keyPattern]: valueDefinition } } : { additionalProperties: valueDefinition }),
    };
    return runtimeSchema({ kind: "record", ...(key ? { key } : {}), item, definition });
}
function recordLiteralKeys(schema) {
    if (schema.kind === "literal") {
        const value = schema.definition?.const;
        return typeof value === "string" || typeof value === "number" ? [value] : undefined;
    }
    if (schema.kind === "enum" && Array.isArray(schema.definition?.enum)) {
        const values = schema.definition.enum.filter((value) => typeof value === "string" || typeof value === "number");
        return values.length === schema.definition.enum.length ? values : undefined;
    }
    if (schema.kind === "union" && Array.isArray(schema.items)) {
        const values = schema.items.flatMap((item) => recordLiteralKeys(item) ?? []);
        return values.length === schema.items.length ? values : undefined;
    }
    return undefined;
}
function recordKeyPattern(schema) {
    if (schema.kind === "integer")
        return "^-?(?:0|[1-9][0-9]*)$";
    if (schema.kind === "number")
        return "^-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?$";
    if (schema.kind === "template-literal")
        return typeof schema.definition?.pattern === "string" ? schema.definition.pattern : "^.*$";
    if (schema.kind === "string")
        return typeof schema.definition?.pattern === "string" ? schema.definition.pattern : "^.*$";
    return undefined;
}
function createComposite(first, second) {
    const items = Array.isArray(first) ? first : [first, second];
    const options = Array.isArray(first) ? second ?? {} : {};
    const shape = {};
    for (const item of items) {
        if (!item?.shape)
            throw new TypeError("Composite requires object schemas");
        for (const [key, value] of Object.entries(item.shape))
            shape[key] = value;
    }
    return t.Object(shape, options);
}
export const t = {
    String: (options) => primitive("string", (value) => typeof value === "string", options),
    Number: (options) => primitive("number", (value) => typeof value === "number" && Number.isFinite(value), options),
    Integer: (options) => primitive("integer", (value) => typeof value === "number" && Number.isInteger(value), options),
    Boolean: (options) => primitive("boolean", (value) => typeof value === "boolean", options),
    BigInt: (options) => {
        validateSchemaOptions(options ?? {}, "bigint");
        return runtimeSchema({
            kind: "bigint",
            definition: { ...schemaDefinition("integer", options ?? {}), "x-nelysia-kind": "bigint" },
        });
    },
    Null: (options) => runtimeSchema({ kind: "null", definition: schemaDefinition("null", options ?? {}) }),
    Never: (options) => runtimeSchema({ kind: "never", definition: schemaDefinition("never", options ?? {}) }),
    Ref: (id, options) => {
        if (!id)
            throw new TypeError("Schema reference id must not be empty");
        let normalized;
        const schema = {
            kind: "ref",
            definition: schemaWithOptions({ $ref: id }, options ?? {}),
            validate(value, path = "body") {
                return validateSchema(value, normalized, { path });
            }
        };
        normalized = normalizeSchemaIR(schema);
        return schema;
    },
    Cyclic: (builder, options = {}) => {
        const id = typeof options.$id === "string" && options.$id.length > 0 ? options.$id : `NelysiaCyclic${++cyclicSchemaId}`;
        const self = t.Ref(id);
        const target = builder(self);
        const definition = schemaWithOptions({ ...(target.definition ?? { type: target.kind }), $id: id }, options);
        let normalized;
        const schema = {
            ...target,
            definition,
            validate(value, path = "body") {
                const maxDepth = typeof options.maxDepth === "number" ? options.maxDepth : 32;
                return validateSchema(value, normalized, { path, references: { [id]: normalized }, maxDepth });
            }
        };
        normalized = normalizeSchemaIR(schema);
        return schema;
    },
    Object: (shape, options = {}) => {
        validateSchemaOptions(options, "object");
        let normalized;
        const schema = {
            kind: "object",
            shape,
            additionalProperties: options.additionalProperties,
            definition: { ...schemaDefinition("object", options), properties: Object.fromEntries(Object.entries(shape).map(([key, schema]) => [key, schema.definition ?? { type: schema.kind }])), required: Object.entries(shape).filter(([, schema]) => !schema.optional).map(([key]) => key) },
            async validate(value, path = "body") {
                if (normalized.capability === "compiled")
                    return await validateSchemaAsync(value, normalized, { path });
                if (typeof value !== "object" || value === null || Array.isArray(value))
                    throw new HttpError(400, `${path} must be object`);
                const input = value;
                const keys = Object.keys(input);
                if (typeof options.minProperties === "number" && keys.length < options.minProperties)
                    throw new HttpError(400, `${path} must have at least ${options.minProperties} properties`);
                if (typeof options.maxProperties === "number" && keys.length > options.maxProperties)
                    throw new HttpError(400, `${path} must have at most ${options.maxProperties} properties`);
                const extraKeys = keys.filter((key) => !Object.prototype.hasOwnProperty.call(shape, key));
                if (options.additionalProperties === false && extraKeys.length > 0)
                    throw new HttpError(400, `${path} must not contain additional properties`);
                const output = {};
                for (const [key, schema] of Object.entries(shape)) {
                    const field = input[key];
                    if (field === undefined && schema.optional)
                        continue;
                    setSafeProperty(output, key, await schema.validate(field, `${path}.${key}`));
                }
                if (options.additionalProperties === true)
                    for (const key of extraKeys)
                        setSafeProperty(output, key, input[key]);
                if (isSchemaValue(options.additionalProperties)) {
                    for (const key of extraKeys)
                        setSafeProperty(output, key, await options.additionalProperties.validate(input[key], `${path}.${key}`));
                }
                return output;
            }
        };
        normalized = normalizeSchemaIR(schema);
        return schema;
    },
    Array: (item, options = {}) => {
        validateSchemaOptions(options, "array");
        let normalized;
        const schema = {
            kind: "array",
            item,
            definition: { ...schemaDefinition("array", options), items: item.definition ?? { type: item.kind } },
            async validate(value, path = "body") {
                if (normalized.capability === "compiled")
                    return await validateSchemaAsync(value, normalized, { path });
                if (!Array.isArray(value))
                    throw new HttpError(400, `${path} must be array`);
                if (typeof options.minItems === "number" && value.length < options.minItems)
                    throw new HttpError(400, `${path} has too few items; minimum is ${options.minItems}`);
                if (typeof options.maxItems === "number" && value.length > options.maxItems)
                    throw new HttpError(400, `${path} has too many items; maximum is ${options.maxItems}`);
                if (options.uniqueItems === true) {
                    const seen = new Set();
                    for (const entry of value) {
                        const identity = JSON.stringify(entry) ?? String(entry);
                        if (seen.has(identity))
                            throw new HttpError(400, `${path} must contain unique items`);
                        seen.add(identity);
                    }
                }
                return Promise.all(value.map((entry, index) => item.validate(entry, `${path}.${index}`)));
            }
        };
        normalized = normalizeSchemaIR(schema);
        return schema;
    },
    Tuple: (items, options = {}) => {
        validateSchemaOptions(options, "tuple");
        const definition = {
            ...schemaDefinition("array", options),
            prefixItems: items.map((item) => item.definition ?? { type: item.kind }),
            minItems: options.minItems ?? items.length,
            maxItems: options.maxItems ?? items.length,
        };
        return runtimeSchema({ kind: "tuple", items, definition });
    },
    Literal: (value, options) => ({
        kind: "literal",
        definition: schemaWithOptions({ const: value }, options ?? {}),
        validate(input, path = "body") {
            if (input !== value)
                throw new HttpError(400, `${path} must be ${String(value)}`);
            return value;
        }
    }),
    Union: (items, options) => ({
        kind: "union",
        items,
        definition: schemaWithOptions({ anyOf: items.map((item) => item.definition ?? { type: item.kind }) }, options ?? {}),
        async validate(value, path = "body") {
            for (const item of items) {
                try {
                    return await item.validate(value, path);
                }
                catch { /* try next branch */ }
            }
            throw new HttpError(400, `${path} does not match any allowed value`);
        }
    }),
    Nullable: (item, options) => ({
        kind: "nullable",
        inner: item,
        definition: schemaWithOptions({ anyOf: [item.definition ?? { type: item.kind }, { type: "null" }] }, options ?? {}),
        validate(value, path = "body") {
            if (value === null)
                return null;
            return item.validate(value, path);
        }
    }),
    Optional: (item, options) => ({
        kind: item.kind,
        optional: true,
        inner: item,
        definition: schemaWithOptions({ ...(item.definition ?? { type: item.kind }), "x-nelysia-optional": true }, options ?? {}),
        validate(value, path = "body") {
            if (value === undefined)
                return undefined;
            return item.validate(value, path);
        }
    }),
    Any: (options) => ({ kind: "any", definition: schemaDefinition("any", options ?? {}), validate: (value) => value }),
    Unknown: (options) => ({ kind: "unknown", definition: schemaDefinition("unknown", options ?? {}), validate: (value) => value }),
    Date: (options) => ({
        kind: "date",
        definition: schemaWithOptions({ type: "string", format: "date-time" }, options ?? {}),
        validate(value, path = "body") {
            if (!(value instanceof Date) || Number.isNaN(value.getTime()))
                throw new HttpError(400, `${path} must be date`);
            return value;
        }
    }),
    TemplateLiteral: (parts, options = {}) => {
        validateSchemaOptions(options, "template-literal");
        const normalizedParts = typeof parts === "string" ? parseTemplateLiteral(parts) : parts;
        const generatedPattern = `^${normalizedParts.map(templateFragment).join("")}$`;
        const definition = schemaWithOptions({ type: "string", pattern: generatedPattern, "x-templateLiteral": true }, options);
        return runtimeSchema({ kind: "template-literal", templateParts: normalizedParts, definition });
    },
    Partial: (schema, options) => {
        const shape = Object.fromEntries(Object.entries(schema.shape).map(([key, item]) => [key, t.Optional(item)]));
        return t.Object(shape, objectOptionsFromSchema(schema, options));
    },
    Pick: (schema, keys, options) => {
        const shape = Object.fromEntries(keys.map((key) => [key, schema.shape[key]]));
        return t.Object(shape, objectOptionsFromSchema(schema, options));
    },
    Omit: (schema, keys, options) => {
        const excluded = new Set(keys);
        const shape = Object.fromEntries(Object.entries(schema.shape).filter(([key]) => !excluded.has(key)));
        return t.Object(shape, objectOptionsFromSchema(schema, options));
    },
    Intersect: (items, options) => ({
        kind: "intersect",
        items,
        definition: schemaWithOptions({ allOf: items.map((item) => item.definition ?? { type: item.kind }) }, options ?? {}),
        async validate(value, path = "body") {
            let output = value;
            for (const item of items) {
                const validated = await item.validate(output, path);
                output = typeof output === "object" && output !== null && typeof validated === "object" && validated !== null
                    ? { ...output, ...validated }
                    : validated;
            }
            return output;
        }
    }),
    Enum: (values, options) => {
        const entries = Array.isArray(values)
            ? [...values]
            : Object.keys(values).filter((key) => Number.isNaN(Number(key))).map((key) => values[key]);
        return {
            kind: "enum",
            definition: schemaWithOptions({ enum: entries }, options ?? {}),
            validate(value, path = "body") {
                if (!entries.some((entry) => Object.is(entry, value)))
                    throw new HttpError(400, `${path} must be one of ${entries.join(", ")}`);
                return value;
            }
        };
    },
    Record: createRecord,
    Required: (schema, options = {}) => {
        const shape = Object.fromEntries(Object.entries(schema.shape).map(([key, item]) => [key, unwrapOptional(item)]));
        return t.Object(shape, objectOptionsFromSchema(schema, options));
    },
    Readonly: (schema, options = {}) => {
        return t.Object(schema.shape, { ...objectOptionsFromSchema(schema, options), readOnly: true });
    },
    Composite: createComposite,
};
function schemaDefinition(kind, options) {
    const definition = { type: kind };
    applySchemaOptions(definition, options);
    return definition;
}
function applySchemaOptions(definition, options) {
    for (const [key, value] of Object.entries(options)) {
        if (value === undefined)
            continue;
        if (typeof value === "bigint") {
            definition[key] = value.toString();
            definition[`x-${key}Type`] = "bigint";
        }
        else if (key === "pattern" && value instanceof RegExp) {
            definition[key] = value.source;
            definition["x-patternFlags"] = value.flags;
        }
        else if (key === "additionalProperties" && isSchemaValue(value)) {
            definition[key] = value.definition ?? { type: value.kind };
        }
        else {
            definition[key] = value;
        }
    }
}
function isSchemaValue(value) {
    return typeof value === "object" && value !== null && typeof value.kind === "string" && typeof value.validate === "function";
}
function schemaOptionsFromDefinition(definition) {
    if (!definition)
        return {};
    const structural = new Set(["type", "properties", "required", "items", "prefixItems", "anyOf", "allOf", "const", "enum", "additionalProperties", "x-templateLiteral"]);
    const options = {};
    for (const [key, value] of Object.entries(definition)) {
        if (!structural.has(key) && !key.startsWith("x-"))
            options[key] = value;
    }
    return options;
}
function objectOptionsFromSchema(schema, options) {
    return {
        ...schemaOptionsFromDefinition(schema.definition),
        ...(schema.additionalProperties !== undefined ? { additionalProperties: schema.additionalProperties } : {}),
        ...(options ?? {}),
    };
}
function unwrapOptional(schema) {
    return schema.optional === true && schema.inner ? schema.inner : schema;
}
function templateFragment(part) {
    if (typeof part === "string")
        return escapePattern(part);
    if (part.kind === "literal")
        return escapePattern(String(part.definition?.const ?? ""));
    if (part.kind === "enum" && Array.isArray(part.definition?.enum))
        return `(?:${part.definition.enum.map((value) => escapePattern(String(value))).join("|")})`;
    if (part.kind === "integer" || part.kind === "number")
        return "-?(?:0|[1-9]\\d*)(?:\\.\\d+)?";
    if (part.kind === "boolean")
        return "(?:true|false)";
    if (part.kind === "bigint")
        return "-?(?:0|[1-9]\\d*)n";
    return ".*";
}
function parseTemplateLiteral(template) {
    const parts = [];
    const token = /\$\{([^}]+)\}/g;
    let cursor = 0;
    for (let match = token.exec(template); match; match = token.exec(template)) {
        if (match.index > cursor)
            parts.push(template.slice(cursor, match.index));
        const expression = match[1]?.trim();
        if (expression === "number")
            parts.push(t.Number());
        else if (expression === "integer")
            parts.push(t.Integer());
        else if (expression === "boolean")
            parts.push(t.Boolean());
        else if (expression === "bigint")
            parts.push(t.BigInt());
        else
            parts.push(`\${${match[1]}}`);
        cursor = match.index + match[0].length;
    }
    if (cursor < template.length)
        parts.push(template.slice(cursor));
    return parts;
}
function escapePattern(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function validatePrimitiveOptions(kind, value, options, path) {
    if (kind === "string" && typeof value === "string") {
        if (typeof options.minLength === "number" && value.length < options.minLength)
            throw new HttpError(400, `${path} is too short; minimum length is ${options.minLength}`);
        if (typeof options.maxLength === "number" && value.length > options.maxLength)
            throw new HttpError(400, `${path} is too long; maximum length is ${options.maxLength}`);
        if (options.pattern instanceof RegExp) {
            if (!new RegExp(options.pattern.source, options.pattern.flags).test(value))
                throw new HttpError(400, `${path} has an invalid format`);
        }
        else if (typeof options.pattern === "string") {
            if (!new RegExp(options.pattern).test(value))
                throw new HttpError(400, `${path} has an invalid format`);
        }
        if (typeof options.format === "string")
            validateStringFormat(value, options.format, path);
        return;
    }
    if ((kind !== "number" && kind !== "integer") || typeof value !== "number")
        return;
    if (typeof options.minimum === "number" && value < options.minimum)
        throw new HttpError(400, `${path} is below minimum`);
    if (typeof options.maximum === "number" && value > options.maximum)
        throw new HttpError(400, `${path} is above maximum`);
    if (typeof options.exclusiveMinimum === "number" && value <= options.exclusiveMinimum)
        throw new HttpError(400, `${path} is below exclusive minimum`);
    if (typeof options.exclusiveMaximum === "number" && value >= options.exclusiveMaximum)
        throw new HttpError(400, `${path} is above exclusive maximum`);
    if (typeof options.multipleOf === "number" && options.multipleOf > 0) {
        const quotient = value / options.multipleOf;
        if (Math.abs(quotient - Math.round(quotient)) > Number.EPSILON * Math.max(1, Math.abs(quotient)))
            throw new HttpError(400, `${path} must be a multiple of ${options.multipleOf}`);
    }
}
function validateStringFormat(value, format, path) {
    if (format === "date-time" && Number.isNaN(Date.parse(value)))
        throw new HttpError(400, `${path} has an invalid format`);
    if (format === "date" && (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T00:00:00Z`))))
        throw new HttpError(400, `${path} has an invalid format`);
    if (format === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))
        throw new HttpError(400, `${path} has an invalid format`);
    if (format === "uuid" && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value))
        throw new HttpError(400, `${path} has an invalid format`);
    if (format === "url" || format === "uri") {
        try {
            new URL(value);
        }
        catch {
            throw new HttpError(400, `${path} has an invalid format`);
        }
    }
}
function setSafeProperty(target, key, value) {
    if (key === "__proto__" || key === "constructor" || key === "prototype") {
        Object.defineProperty(target, key, { value, enumerable: true, configurable: true, writable: true });
        return;
    }
    target[key] = value;
}
export function fromStandardSchema(schema) {
    const definition = inferPropertyDefinition(schema);
    return {
        kind: "standard",
        definition,
        async validate(value, path = "body") {
            const result = await schema["~standard"].validate(value);
            if (typeof result === "object" && result !== null && "issues" in result) {
                const issue = result.issues[0];
                const issuePath = issue?.path?.map((part) => String(part)).join(".");
                throw new HttpError(400, `${path}${issuePath ? `.${issuePath}` : ""}: ${issue?.message ?? "Invalid value"}`);
            }
            if (typeof result === "object" && result !== null && "value" in result)
                return result.value;
            return result;
        }
    };
}
function inferPropertyDefinition(field) {
    if (typeof field === "object" && field !== null) {
        const f = field;
        if (f.optional === true)
            return inferPropertyDefinition({ ...f, optional: undefined });
        if (isRecord(f.definition))
            return decorateDefinition(f.definition, f);
        const rawDef = isRecord(f._def) ? f._def : undefined;
        const source = rawDef ?? f;
        const shapeValue = source.shape ?? f.shape;
        const shape = typeof shapeValue === "function" ? shapeValue() : shapeValue;
        if (typeof shape === "object" && shape !== null) {
            const properties = {};
            const required = [];
            for (const [key, value] of Object.entries(shape)) {
                const property = inferPropertyDefinition(value) ?? { type: "string" };
                properties[key] = property;
                if (!isOptionalStandardField(value))
                    required.push(key);
            }
            return decorateDefinition({ type: "object", properties, required }, f);
        }
        const typeName = typeof source.typeName === "string" ? source.typeName : typeof source.type === "string" ? source.type : "";
        const normalizedType = typeName.replace(/^Zod/, "").toLowerCase();
        const inner = source.innerType ?? source.wrapped ?? source.item ?? source.element;
        if (normalizedType === "optional" || normalizedType === "default")
            return inferPropertyDefinition(inner);
        if (normalizedType === "nullable") {
            const innerDefinition = inferPropertyDefinition(inner) ?? {};
            return decorateDefinition({ anyOf: [innerDefinition, { type: "null" }] }, f);
        }
        if (normalizedType === "array")
            return decorateDefinition({ type: "array", items: inferPropertyDefinition(source.items ?? source.type) ?? {} }, f);
        if (normalizedType === "union")
            return decorateDefinition({ anyOf: toDefinitions(source.options ?? source.anyOf) }, f);
        if (normalizedType === "intersection" || normalizedType === "intersect")
            return decorateDefinition({ allOf: toDefinitions(source.types ?? source.items) }, f);
        if (normalizedType === "tuple")
            return decorateDefinition({ type: "array", prefixItems: toDefinitions(source.items), minItems: Array.isArray(source.items) ? source.items.length : undefined }, f);
        if (normalizedType === "literal")
            return decorateDefinition({ const: source.value ?? source.const }, f);
        if (normalizedType === "enum")
            return decorateDefinition({ enum: Array.isArray(source.values) ? source.values : isRecord(source.entries) ? Object.values(source.entries) : [] }, f);
        if (normalizedType === "record" || normalizedType === "map")
            return decorateDefinition({ type: "object", additionalProperties: inferPropertyDefinition(source.value ?? source.values ?? source.valueType) ?? {} }, f);
        if (typeof f.type === "string")
            return decorateDefinition({ type: normalizeOpenApiType(f.type) }, f);
        if (typeof source.typeName === "string")
            return decorateDefinition({ type: normalizeOpenApiType(normalizedType) }, f);
    }
    return undefined;
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function toDefinitions(value) {
    return Array.isArray(value) ? value.map((item) => inferPropertyDefinition(item) ?? {}) : [];
}
function normalizeOpenApiType(value) {
    if (value === "date" || value === "datetime" || value === "date-time")
        return "string";
    if (value === "integer")
        return "integer";
    if (value === "int" || value === "float" || value === "double")
        return "number";
    return value === "object" || value === "string" || value === "number" || value === "boolean" || value === "null" ? value : "string";
}
function decorateDefinition(definition, metadata) {
    const output = { ...definition };
    const keys = [
        ["description", "description"], ["examples", "examples"], ["default", "default"],
        ["minimum", "minimum"], ["maximum", "maximum"], ["min", "minimum"], ["max", "maximum"],
        ["minLength", "minLength"], ["maxLength", "maxLength"], ["minItems", "minItems"], ["maxItems", "maxItems"],
        ["pattern", "pattern"], ["format", "format"]
    ];
    for (const [source, target] of keys)
        if (metadata[source] !== undefined)
            output[target] = metadata[source];
    if (metadata.integer === true || metadata.isInt === true)
        output.type = "integer";
    if (metadata.date === true || metadata.datetime === true) {
        output.type = "string";
        output.format = "date-time";
    }
    return output;
}
function isOptionalStandardField(field) {
    if (typeof field !== "object" || field === null)
        return false;
    if (field.optional === true)
        return true;
    const def = field._def;
    if (typeof def !== "object" || def === null)
        return false;
    return def.typeName === "ZodOptional";
}
//# sourceMappingURL=schema.js.map