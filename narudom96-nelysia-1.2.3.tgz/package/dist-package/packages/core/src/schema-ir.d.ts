import type { Schema } from "./schema.ts";
export type SchemaCapability = "compiled" | "reference" | "unsupported";
export interface SchemaIRNode {
    readonly kind: string;
    readonly definition: Readonly<Record<string, unknown>>;
    readonly children: readonly SchemaIRNode[];
    readonly childKeys: readonly string[];
    readonly options: Readonly<Record<string, unknown>>;
    readonly capability: SchemaCapability;
    readonly optional?: boolean;
    readonly id?: string;
    readonly ref?: string;
    readonly additionalProperties?: SchemaIRNode | boolean;
}
export interface SchemaIR {
    readonly root: SchemaIRNode;
    readonly definitions: Readonly<Record<string, SchemaIRNode>>;
    readonly capability: SchemaCapability;
    readonly hash: string;
}
export type SchemaReference = Schema | SchemaIR | SchemaIRNode;
export type SchemaReferenceRegistry = ReadonlyMap<string, SchemaReference> | Readonly<Record<string, SchemaReference>>;
/**
 * Normalize a public schema into the immutable representation shared by the
 * reference validator, compiler, and OpenAPI adapters.
 */
export declare function normalizeSchemaIR(schema: Schema): SchemaIR;
export declare function schemaCapability(ir: SchemaIR | SchemaIRNode): SchemaCapability;
/** Return a normalized object-property child without exposing mutable schema internals. */
export declare function schemaIRChild(node: SchemaIRNode, key: string): SchemaIRNode | undefined;
export declare function resolveSchemaReference(id: string, registry: SchemaReferenceRegistry): SchemaIRNode;
export declare function schemaIRHash(ir: SchemaIR | SchemaIRNode): string;
//# sourceMappingURL=schema-ir.d.ts.map