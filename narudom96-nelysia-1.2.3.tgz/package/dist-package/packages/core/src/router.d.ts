import type { HttpMethod, RouteRecord } from "./types.ts";
export declare function compilePath(path: string): Pick<RouteRecord, "segments" | "params" | "static" | "wildcard">;
export declare function matchRoute(route: RouteRecord, pathname: string): Record<string, string> | undefined;
export declare function normalizePathname(pathname: string): string;
export declare function splitSegments(normalizedPathname: string): string[];
export declare function matchSegments(route: RouteRecord, actual: string[]): Record<string, string> | undefined;
export interface RouterMatch {
    route: RouteRecord;
    params: Record<string, string>;
}
/** Single-pass dynamic lookup within one HTTP method. Caller splits the pathname once. */
export declare function lookupDynamicRoute(candidates: readonly RouteRecord[], actual: string[]): RouterMatch | undefined;
/**
 * Dynamic lookup that keeps registration order but avoids allocating a
 * segment array for the common `/static-prefix/:id` shape. More complex route
 * patterns continue through the reference segment matcher unchanged.
 */
export declare function lookupDynamicPath(candidates: readonly RouteRecord[], pathname: string): RouterMatch | undefined;
/** URL-aware counterpart for adapters that already have the original request
 * URL. Simple dynamic routes can be matched without first slicing the host,
 * pathname, query, and segment array into separate allocations. */
export declare function lookupDynamicUrl(candidates: readonly RouteRecord[], url: string): RouterMatch | undefined;
/** Fast result-only matcher used when a method has exactly one simple dynamic
 * route. It avoids allocating the RouterMatch wrapper. */
export declare function matchSingleDynamicUrl(route: RouteRecord, url: string): Record<string, string> | undefined;
/** Result-only counterpart for callers that already extracted the pathname. */
export declare function matchSingleDynamicPath(route: RouteRecord, pathname: string): Record<string, string> | undefined;
export declare function isSingleParamRoute(route: RouteRecord): boolean;
/** Cold-path helper: does any route (any method) match this pathname? Used only for 404/405/OPTIONS. */
export declare function matchAnyMethod(routes: readonly RouteRecord[], actual: string[]): boolean;
/** Cold-path helper: build the `Allow` header value without re-splitting per route. */
export declare function allowedMethodsFor(routes: readonly RouteRecord[], actual: string[]): string;
export declare function normalizeMethod(method: string): HttpMethod;
//# sourceMappingURL=router.d.ts.map