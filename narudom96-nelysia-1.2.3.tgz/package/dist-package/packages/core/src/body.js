import { HttpError } from "./types.js";
export function isJsonContentType(contentType) {
    if (!contentType)
        return false;
    const mediaType = contentType.split(";", 1)[0]?.trim().toLowerCase() ?? "";
    return mediaType === "application/json" || mediaType.endsWith("+json");
}
export function isMultipartContentType(contentType) {
    return contentType?.split(";", 1)[0]?.trim().toLowerCase() === "multipart/form-data";
}
export function isFormUrlEncodedContentType(contentType) {
    return contentType?.split(";", 1)[0]?.trim().toLowerCase() === "application/x-www-form-urlencoded";
}
export function parseFormUrlEncoded(text) {
    const params = new URLSearchParams(text);
    const output = {};
    for (const key of new Set(params.keys())) {
        const values = params.getAll(key);
        output[key] = values.length > 1 ? values : values[0];
    }
    return output;
}
export async function parseWebRequestBody(request, limit) {
    if (request.method === "GET" || request.method === "HEAD" || request.body === null)
        return undefined;
    const declaredLength = Number(request.headers.get("content-length") ?? 0);
    if (Number.isFinite(declaredLength) && declaredLength > limit)
        throw new HttpError(413, "Request body is too large");
    if (isMultipartContentType(request.headers.get("content-type"))) {
        const bytes = await readBounded(request.body, limit);
        if (bytes.byteLength === 0)
            return undefined;
        const copy = new Request(request.url, { method: request.method, headers: request.headers, body: bytes });
        return copy.formData();
    }
    const bytes = await readBounded(request.body, limit);
    if (bytes.byteLength === 0)
        return undefined;
    const text = new TextDecoder().decode(bytes);
    if (isJsonContentType(request.headers.get("content-type"))) {
        try {
            return JSON.parse(text);
        }
        catch {
            throw new HttpError(400, "Malformed JSON body");
        }
    }
    if (isFormUrlEncodedContentType(request.headers.get("content-type"))) {
        return parseFormUrlEncoded(text);
    }
    return text;
}
async function readBounded(stream, limit) {
    if (!stream)
        return new Uint8Array();
    const reader = stream.getReader();
    const chunks = [];
    let size = 0;
    try {
        while (true) {
            const chunk = await reader.read();
            if (chunk.done)
                break;
            size += chunk.value.byteLength;
            if (size > limit) {
                await reader.cancel("body limit exceeded").catch(() => undefined);
                throw new HttpError(413, "Request body is too large");
            }
            chunks.push(chunk.value);
        }
    }
    finally {
        reader.releaseLock();
    }
    const output = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) {
        output.set(chunk, offset);
        offset += chunk.byteLength;
    }
    return output;
}
//# sourceMappingURL=body.js.map