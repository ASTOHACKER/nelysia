export declare function isJsonContentType(contentType: string | null | undefined): boolean;
export declare function isMultipartContentType(contentType: string | null | undefined): boolean;
export declare function isFormUrlEncodedContentType(contentType: string | null | undefined): boolean;
export declare function parseFormUrlEncoded(text: string): Record<string, string | string[]>;
export declare function parseWebRequestBody(request: Request, limit: number): Promise<unknown>;
//# sourceMappingURL=body.d.ts.map