export async function gracefulShutdown(server, timeoutMs = 10_000) {
    if (server.stop) {
        await server.stop(true);
        return;
    }
    const close = server.close;
    if (!close)
        return;
    await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error(`Server shutdown timed out after ${timeoutMs}ms`)), timeoutMs);
        close.call(server, (error) => {
            clearTimeout(timer);
            if (error)
                reject(error);
            else
                resolve();
        });
        server.closeIdleConnections?.();
    });
}
//# sourceMappingURL=lifecycle.js.map