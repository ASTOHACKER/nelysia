type JsonMethod<Body, StatusMap extends object> = [keyof StatusMap] extends [never] ? {
    <T = Body>(): Promise<T>;
} : {
    <T = Body>(): Promise<T>;
    <Status extends keyof StatusMap>(status: Status): Promise<StatusMap[Status]>;
};
export interface ClientResponse<T, ErrorBody = unknown, StatusMap extends object = {}> {
    data?: T;
    error?: {
        status: number;
        body: ErrorBody;
    };
    response: Response;
    json: JsonMethod<T, StatusMap>;
}
export type ClientQueryArrayPolicy = "repeat" | "comma" | "json";
export interface ClientOptions {
    fetch?: typeof globalThis.fetch;
    headers?: HeadersInit;
    queryArray?: ClientQueryArrayPolicy;
}
export type ClientRouteMap = Record<string, {
    response?: unknown;
    responses?: Record<string | number, unknown>;
    body?: unknown;
    params?: unknown;
    query?: unknown;
    headers?: unknown;
    errors?: unknown;
}>;
type StringKey<T> = Extract<keyof T, string>;
type ExpandPath<Path extends string> = Path extends `${infer Prefix}:${string}/${infer Rest}` ? `${Prefix}${string}/${ExpandPath<Rest>}` : Path extends `${infer Prefix}:${string}` ? `${Prefix}${string}` : Path extends `${infer Prefix}/*` ? `${Prefix}/${string}` : Path;
type RoutePaths<Routes, Method extends string> = {
    [Key in StringKey<Routes>]: Key extends `${Method} ${infer Pattern}` ? Pattern | ExpandPath<Pattern> : never;
}[StringKey<Routes>];
type RouteKeyForPath<Routes, Method extends string, Path extends string> = {
    [Key in StringKey<Routes>]: Key extends `${Method} ${infer Pattern}` ? Path extends ExpandPath<Pattern> ? Key : never : never;
}[StringKey<Routes>];
type RouteEntry<Routes, Method extends string, Path extends string> = Routes[RouteKeyForPath<Routes, Method, Path> & keyof Routes];
type RouteField<Routes, Method extends string, Path extends string, Field extends string, Fallback = never> = RouteEntry<Routes, Method, Path> extends infer Entry ? Entry extends Record<Field, infer Value> ? Value : Fallback : Fallback;
type RouteResponse<Routes, Method extends string, Path extends string> = RouteField<Routes, Method, Path, "response", unknown>;
type RouteResponses<Routes, Method extends string, Path extends string> = RouteField<Routes, Method, Path, "responses", {}>;
type RouteBody<Routes, Method extends string, Path extends string> = RouteField<Routes, Method, Path, "body">;
type RouteQuery<Routes, Method extends string, Path extends string> = RouteField<Routes, Method, Path, "query">;
type RouteParams<Routes, Method extends string, Path extends string> = RouteField<Routes, Method, Path, "params">;
type RouteHeaders<Routes, Method extends string, Path extends string> = RouteField<Routes, Method, Path, "headers">;
type RouteErrors<Routes, Method extends string, Path extends string> = RouteField<Routes, Method, Path, "errors", unknown>;
type HeaderInput<Value> = Value extends Record<string, unknown> ? Value & Record<string, string | number | boolean | undefined> : HeadersInit;
type PathNeedsParams<Path extends string> = Path extends `${string}:${string}` | `${string}/*` ? true : false;
type RequestOptions<Routes, Method extends string, Path extends string> = (PathNeedsParams<Path> extends true ? {
    params: RouteParams<Routes, Method, Path>;
} : {
    params?: RouteParams<Routes, Method, Path>;
}) & {
    query?: RouteQuery<Routes, Method, Path>;
    headers?: HeaderInput<RouteHeaders<Routes, Method, Path>>;
    signal?: AbortSignal;
};
type BodyArguments<Routes, Method extends string, Path extends string> = [RouteBody<Routes, Method, Path>] extends [never] ? [requestOptions?: RequestOptions<Routes, Method, Path>] : [body: RouteBody<Routes, Method, Path>, requestOptions?: RequestOptions<Routes, Method, Path>];
type RoutesOfApp<App> = App extends {
    readonly __nelysiaRouteMap?: infer Routes;
} ? Routes : App extends Record<string, unknown> ? App : never;
type TypedClient<Routes> = {
    get<Path extends RoutePaths<Routes, "GET">>(path: Path, requestOptions?: RequestOptions<Routes, "GET", Path>): Promise<ClientResponse<RouteResponse<Routes, "GET", Path>, RouteErrors<Routes, "GET", Path>, RouteResponses<Routes, "GET", Path>>>;
    post<Path extends RoutePaths<Routes, "POST">>(path: Path, ...args: BodyArguments<Routes, "POST", Path>): Promise<ClientResponse<RouteResponse<Routes, "POST", Path>, RouteErrors<Routes, "POST", Path>, RouteResponses<Routes, "POST", Path>>>;
    put<Path extends RoutePaths<Routes, "PUT">>(path: Path, ...args: BodyArguments<Routes, "PUT", Path>): Promise<ClientResponse<RouteResponse<Routes, "PUT", Path>, RouteErrors<Routes, "PUT", Path>, RouteResponses<Routes, "PUT", Path>>>;
    patch<Path extends RoutePaths<Routes, "PATCH">>(path: Path, ...args: BodyArguments<Routes, "PATCH", Path>): Promise<ClientResponse<RouteResponse<Routes, "PATCH", Path>, RouteErrors<Routes, "PATCH", Path>, RouteResponses<Routes, "PATCH", Path>>>;
    delete<Path extends RoutePaths<Routes, "DELETE">>(path: Path, requestOptions?: RequestOptions<Routes, "DELETE", Path>): Promise<ClientResponse<RouteResponse<Routes, "DELETE", Path>, RouteErrors<Routes, "DELETE", Path>, RouteResponses<Routes, "DELETE", Path>>>;
    head<Path extends RoutePaths<Routes, "HEAD">>(path: Path, requestOptions?: RequestOptions<Routes, "HEAD", Path>): Promise<ClientResponse<RouteResponse<Routes, "HEAD", Path>, RouteErrors<Routes, "HEAD", Path>, RouteResponses<Routes, "HEAD", Path>>>;
    options<Path extends RoutePaths<Routes, "OPTIONS">>(path: Path, requestOptions?: RequestOptions<Routes, "OPTIONS", Path>): Promise<ClientResponse<RouteResponse<Routes, "OPTIONS", Path>, RouteErrors<Routes, "OPTIONS", Path>, RouteResponses<Routes, "OPTIONS", Path>>>;
};
declare function createBaseClient(baseUrl: string, options?: ClientOptions): {
    request: <T, E = unknown, StatusMap extends object = {}>(method: string, path: string, body?: unknown, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
    get: <T, E = unknown, StatusMap extends object = {}>(path: string, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
    post: <T, E = unknown, StatusMap extends object = {}>(path: string, body: unknown, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
    put: <T, E = unknown, StatusMap extends object = {}>(path: string, body: unknown, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
    patch: <T, E = unknown, StatusMap extends object = {}>(path: string, body: unknown, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
    delete: <T, E = unknown, StatusMap extends object = {}>(path: string, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
    head: <T, E = unknown, StatusMap extends object = {}>(path: string, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
    options: <T, E = unknown, StatusMap extends object = {}>(path: string, requestOptions?: {
        headers?: HeadersInit;
        signal?: AbortSignal;
    }) => Promise<ClientResponse<T, E, StatusMap>>;
};
export declare function createClient<App = never>(baseUrl: string, options?: ClientOptions): [App] extends [never] ? ReturnType<typeof createBaseClient> : TypedClient<RoutesOfApp<App>>;
export declare function createTypedClient<Routes>(baseUrl: string, options?: ClientOptions): TypedClient<Routes>;
export {};
//# sourceMappingURL=index.d.ts.map