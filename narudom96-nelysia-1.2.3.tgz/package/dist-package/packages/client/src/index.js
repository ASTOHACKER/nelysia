function toHeaders(input) {
    return new Headers(input);
}
function withQuery(path, query, policy) {
    if (query === undefined || query === null)
        return path;
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) {
        if (value === undefined)
            continue;
        if (Array.isArray(value)) {
            if (policy === "comma")
                search.set(key, value.map(String).join(","));
            else if (policy === "json")
                search.set(key, JSON.stringify(value));
            else
                for (const item of value)
                    search.append(key, String(item));
        }
        else
            search.set(key, String(value));
    }
    const encoded = search.toString();
    return encoded ? `${path}${path.includes("?") ? "&" : "?"}${encoded}` : path;
}
function withParams(path, params) {
    if (params === undefined || params === null)
        return path;
    const values = params;
    return path.replace(/:([A-Za-z0-9_]+)/g, (_, name) => encodeURIComponent(String(values[name] ?? `:${name}`)))
        .replace(/\*$/, () => String(values["*"] ?? "*").split("/").map((segment) => encodeURIComponent(segment)).join("/"));
}
function isRequestOptions(value) {
    if (typeof value !== "object" || value === null || Array.isArray(value))
        return false;
    return Object.keys(value).some((key) => key === "params" || key === "query" || key === "headers" || key === "signal");
}
function resolveUrl(path, baseUrl) {
    if (/^[A-Za-z][A-Za-z0-9+.-]*:/.test(path))
        return path;
    if (/^[A-Za-z][A-Za-z0-9+.-]*:/.test(baseUrl))
        return new URL(path, baseUrl).toString();
    const base = baseUrl.endsWith("/") ? baseUrl.slice(0, -1) : baseUrl;
    const relative = path.startsWith("/") ? path : `/${path}`;
    const joined = `${base}${relative}` || "/";
    if (typeof globalThis.location !== "undefined")
        return new URL(joined, globalThis.location.href).toString();
    return joined;
}
function createBaseClient(baseUrl, options = {}) {
    const fetcher = options.fetch ?? globalThis.fetch;
    const request = async (method, path, body, requestOptions = {}) => {
        const headers = toHeaders(options.headers);
        for (const [key, value] of toHeaders(requestOptions.headers))
            headers.set(key, value);
        if (body !== undefined && !headers.has("content-type"))
            headers.set("content-type", "application/json");
        const response = await fetcher(resolveUrl(path, baseUrl), {
            method,
            headers,
            body: body === undefined ? undefined : (body instanceof Uint8Array || typeof body === "string" ? body : JSON.stringify(body)),
            signal: requestOptions.signal
        });
        const text = await response.text();
        let value = undefined;
        if (text.length > 0) {
            try {
                value = JSON.parse(text);
            }
            catch {
                value = text;
            }
        }
        const json = async (_status) => value;
        return (response.ok ? { data: value, response, json } : { error: { status: response.status, body: value }, response, json });
    };
    return {
        request,
        get: (path, requestOptions) => request("GET", path, undefined, requestOptions),
        post: (path, body, requestOptions) => request("POST", path, body, requestOptions),
        put: (path, body, requestOptions) => request("PUT", path, body, requestOptions),
        patch: (path, body, requestOptions) => request("PATCH", path, body, requestOptions),
        delete: (path, requestOptions) => request("DELETE", path, undefined, requestOptions),
        head: (path, requestOptions) => request("HEAD", path, undefined, requestOptions),
        options: (path, requestOptions) => request("OPTIONS", path, undefined, requestOptions)
    };
}
export function createClient(baseUrl, options = {}) {
    return createBaseClient(baseUrl, options);
}
export function createTypedClient(baseUrl, options = {}) {
    const client = createBaseClient(baseUrl, options);
    const prepare = (path, requestOptions) => ({
        path: withQuery(withParams(path, requestOptions?.params), requestOptions?.query, options.queryArray ?? "repeat"),
        requestOptions: { headers: requestOptions?.headers, signal: requestOptions?.signal }
    });
    return {
        get: (path, requestOptions) => {
            const prepared = prepare(path, requestOptions);
            return client.get(prepared.path, prepared.requestOptions);
        },
        post: (path, bodyOrOptions, requestOptions) => {
            const bodyIsOptions = requestOptions === undefined && isRequestOptions(bodyOrOptions);
            const body = bodyIsOptions ? undefined : bodyOrOptions;
            const options = (bodyIsOptions ? bodyOrOptions : requestOptions);
            const prepared = prepare(path, options);
            return client.post(prepared.path, body, prepared.requestOptions);
        },
        put: (path, bodyOrOptions, requestOptions) => {
            const bodyIsOptions = requestOptions === undefined && isRequestOptions(bodyOrOptions);
            const body = bodyIsOptions ? undefined : bodyOrOptions;
            const options = (bodyIsOptions ? bodyOrOptions : requestOptions);
            const prepared = prepare(path, options);
            return client.put(prepared.path, body, prepared.requestOptions);
        },
        patch: (path, bodyOrOptions, requestOptions) => {
            const bodyIsOptions = requestOptions === undefined && isRequestOptions(bodyOrOptions);
            const body = bodyIsOptions ? undefined : bodyOrOptions;
            const options = (bodyIsOptions ? bodyOrOptions : requestOptions);
            const prepared = prepare(path, options);
            return client.patch(prepared.path, body, prepared.requestOptions);
        },
        delete: (path, requestOptions) => {
            const prepared = prepare(path, requestOptions);
            return client.delete(prepared.path, prepared.requestOptions);
        },
        head: (path, requestOptions) => {
            const prepared = prepare(path, requestOptions);
            return client.head(prepared.path, prepared.requestOptions);
        },
        options: (path, requestOptions) => {
            const prepared = prepare(path, requestOptions);
            return client.options(prepared.path, prepared.requestOptions);
        }
    };
}
//# sourceMappingURL=index.js.map