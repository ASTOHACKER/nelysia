export function drizzleRoute(options) {
    return (app) => {
        app.get(options.path ?? "/db", (context) => options.query(options.db, context));
        return app;
    };
}
//# sourceMappingURL=index.js.map