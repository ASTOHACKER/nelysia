import type { Nelysia } from "../../core/src/app.ts";
import type { Context } from "../../core/src/types.ts";
export interface DrizzleRouteOptions<Database> {
    db: Database;
    path?: string;
    query(database: Database, context: Context): unknown | Promise<unknown>;
}
export declare function drizzleRoute<Database>(options: DrizzleRouteOptions<Database>): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
//# sourceMappingURL=index.d.ts.map