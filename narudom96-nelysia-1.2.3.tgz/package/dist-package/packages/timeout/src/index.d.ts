import type { NelysiaPlugin } from "../../core/src/index.ts";
export interface TimeoutOptions {
    timeoutMs?: number;
    status?: number;
    message?: string;
}
export type TimeoutPlugin = NelysiaPlugin;
export declare function timeout(options?: TimeoutOptions): TimeoutPlugin;
//# sourceMappingURL=index.d.ts.map