import type { Nelysia } from "../../core/src/app.ts";
declare module "../../core/src/types.ts" {
    interface AuthStrategyRegistry {
        session: unknown;
    }
}
export interface BetterAuthLike {
    handler(request: Request): Response | Promise<Response>;
    /** Optional session resolver used by routes with auth: "session". */
    getSession?(request: Request): unknown | Promise<unknown>;
}
export declare function betterAuthPlugin(auth: BetterAuthLike, prefix?: string): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
//# sourceMappingURL=index.d.ts.map