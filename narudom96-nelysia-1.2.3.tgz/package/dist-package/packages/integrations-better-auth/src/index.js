export function betterAuthPlugin(auth, prefix = "/api/auth") {
    return (app) => {
        if (auth.getSession !== undefined) {
            app.registerAuthStrategy("session", {
                guard: async (context) => {
                    const value = await auth.getSession(new Request(toAbsoluteUrl(context.request.url), { method: "GET", headers: context.headers }));
                    if (value === undefined || value === null) {
                        const optional = typeof context.route?.auth === "object" && context.route.auth.optional === true;
                        if (optional)
                            return;
                        return context.response(401, { error: "Unauthorized" });
                    }
                    context.auth = value;
                }
            });
        }
        app.all(`${prefix}/*`, async (context) => {
            const headers = new Headers(context.request.headers);
            const init = { method: context.request.method, headers };
            if (!["GET", "HEAD"].includes(context.request.method) && context.body !== undefined)
                init.body = typeof context.body === "string" ? context.body : JSON.stringify(context.body);
            return auth.handler(new Request(toAbsoluteUrl(context.request.url), init));
        });
        return app;
    };
}
function toAbsoluteUrl(url) {
    return url.includes("://") ? url : `http://localhost${url.startsWith("/") ? url : `/${url}`}`;
}
//# sourceMappingURL=index.js.map