import { type Nelysia } from "../../core/src/app.ts";
export interface FetchRequestContext {
    env?: unknown;
    executionContext?: unknown;
}
export declare function createFetchHandler(app: Nelysia<any, any, any>): (request: Request, context?: FetchRequestContext) => Promise<Response>;
//# sourceMappingURL=server.d.ts.map