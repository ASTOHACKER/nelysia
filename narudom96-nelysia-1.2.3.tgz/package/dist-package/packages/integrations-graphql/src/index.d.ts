import { type GraphQLSchema } from "graphql";
import type { Nelysia } from "../../core/src/app.ts";
export interface GraphQLOptions {
    schema: GraphQLSchema;
    path?: string;
    context?(context: unknown): unknown | Promise<unknown>;
}
export declare function graphqlPlugin(options: GraphQLOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
//# sourceMappingURL=index.d.ts.map