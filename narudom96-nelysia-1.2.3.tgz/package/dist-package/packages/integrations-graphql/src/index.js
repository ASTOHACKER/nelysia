import { graphql } from "graphql";
export function graphqlPlugin(options) {
    const path = options.path ?? "/graphql";
    return (app) => {
        app.post(path, async (context) => {
            const body = context.body;
            if (!body?.query)
                return context.response(400, { errors: [{ message: "GraphQL query is required" }] });
            const result = await graphql({
                schema: options.schema,
                source: body.query,
                variableValues: body.variables,
                operationName: body.operationName,
                contextValue: await options.context?.(context)
            });
            return context.response(200, JSON.parse(JSON.stringify(result)), { "content-type": "application/json; charset=utf-8" });
        });
        return app;
    };
}
//# sourceMappingURL=index.js.map