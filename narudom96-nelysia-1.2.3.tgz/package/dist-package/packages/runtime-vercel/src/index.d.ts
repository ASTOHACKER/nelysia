import type { Nelysia } from "../../core/src/app.ts";
export declare function createVercelHandler(app: Nelysia<any, any, any>): (request: Request) => Promise<Response>;
//# sourceMappingURL=index.d.ts.map