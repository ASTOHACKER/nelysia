import { createFetchHandler } from "../../runtime-fetch/src/server.js";
export function createVercelHandler(app) {
    return createFetchHandler(app);
}
//# sourceMappingURL=index.js.map