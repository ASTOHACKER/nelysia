#!/usr/bin/env node
export declare function generateClientFile(entry: string, output: string, force?: boolean): Promise<void>;
export declare function generateFeatureModule(name: string, root?: string): Promise<string[]>;
export declare function createProject(name: string, root?: string): Promise<string[]>;
export declare function loadApplication(entry: string): Promise<any>;
export declare function formatRoutes(app: {
    graph: {
        routes: readonly {
            method: string;
            path: string;
        }[];
    };
}): string;
export declare function doctor(app: {
    graph: {
        routes: readonly {
            method: string;
            path: string;
        }[];
    };
}, options?: {
    strict?: boolean;
}): Promise<{
    ok: boolean;
    output: string;
}>;
//# sourceMappingURL=index.d.ts.map