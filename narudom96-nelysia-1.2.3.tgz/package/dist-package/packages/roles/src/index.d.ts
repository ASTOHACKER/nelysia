import { type Context, type Hook, type NelysiaPlugin } from "../../core/src/index.ts";
export interface RolesOptions {
    resolveRoles?(context: Context): string[] | readonly string[] | Promise<string[] | readonly string[]>;
    permissions?: Record<string, readonly string[]>;
}
export interface PermissionApi {
    roles: readonly string[];
    has(role: string): boolean;
    can(permission: string): boolean;
    require(...roles: string[]): void;
}
export interface RolesContext {
    permissions: PermissionApi;
}
export type RolesPlugin = NelysiaPlugin<RolesContext>;
export declare function roles(options?: RolesOptions): RolesPlugin;
export declare function requireRole(...required: string[]): Hook;
//# sourceMappingURL=index.d.ts.map