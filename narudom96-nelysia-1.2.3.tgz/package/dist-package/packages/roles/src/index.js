import { HttpError } from "../../core/src/index.js";
export function roles(options = {}) {
    const permissionMap = new Map(Object.entries(options.permissions ?? {}).map(([permission, allowedRoles]) => [permission, new Set(allowedRoles)]));
    return ((app) => app.derive(async (context) => {
        const resolved = await options.resolveRoles?.(context) ?? [];
        const values = [...resolved];
        const set = new Set(values);
        const permissions = {
            roles: values,
            has: (role) => set.has(role),
            can: (permission) => {
                const allowed = permissionMap.get(permission);
                return allowed === undefined ? false : values.some((role) => allowed.has(role));
            },
            require: (...required) => {
                if (required.length === 0 || !required.some((role) => set.has(role)))
                    throw new HttpError(403, "Forbidden");
            }
        };
        return { permissions };
    }));
}
export function requireRole(...required) {
    if (required.length === 0)
        throw new Error("requireRole needs at least one role");
    return ({ permissions }) => {
        if (permissions === undefined || !required.some((role) => permissions.has(role)))
            return new Response("Forbidden", { status: 403 });
    };
}
//# sourceMappingURL=index.js.map