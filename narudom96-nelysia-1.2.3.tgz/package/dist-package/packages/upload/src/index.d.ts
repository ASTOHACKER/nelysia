import { type Context, type NelysiaPlugin, type UploadedFile } from "../../core/src/index.ts";
export interface UploadStorage {
    store(file: UploadedFile, context: Context): unknown | Promise<unknown>;
    remove?(stored: unknown, context: Context): void | Promise<void>;
}
export interface UploadOptions {
    maxFileSize?: number;
    maxFiles?: number;
    fields?: string[];
    storage?: UploadStorage;
}
export interface UploadContext {
    files?: Record<string, UploadedFile[]>;
}
export type UploadPlugin = NelysiaPlugin<UploadContext>;
export declare function memoryStorage(): UploadStorage;
export declare function diskStorage(root: string): UploadStorage;
export declare function upload(options?: UploadOptions): UploadPlugin;
//# sourceMappingURL=index.d.ts.map