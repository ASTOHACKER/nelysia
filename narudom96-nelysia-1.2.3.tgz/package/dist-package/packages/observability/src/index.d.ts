import type { Telemetry } from "../../core/src/types.ts";
export interface OtlpHttpExporterOptions {
    url: string;
    headers?: Record<string, string>;
    fetch?: typeof globalThis.fetch;
    serviceName?: string;
}
export declare function otlpHttpExporter(options: OtlpHttpExporterOptions): Pick<Telemetry, "exportSpan">;
//# sourceMappingURL=index.d.ts.map