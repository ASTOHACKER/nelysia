import type { Nelysia } from "../../core/src/app.ts";
import { type Schema } from "../../core/src/schema.ts";
import { type SchemaIR, type SchemaIRNode } from "../../core/src/schema-ir.ts";
export interface OpenAPIOptions {
    title?: string;
    version?: string;
    path?: string;
}
export interface OpenAPIUiOptions {
    path?: string;
    specPath?: string;
    title?: string;
}
export interface SwaggerUiOptions {
    path?: string;
    specPath?: string;
    title?: string;
}
export type SchemaOutputDialect = "openapi-3.0" | "openapi-3.1" | "json-schema-2020-12";
export interface SchemaConversionContext {
    readonly dialect?: SchemaOutputDialect;
    readonly components?: Record<string, unknown>;
    readonly definitions?: Readonly<Record<string, Schema | SchemaIR | SchemaIRNode>>;
    readonly stable?: boolean;
}
type SchemaInput = Schema | SchemaIR | SchemaIRNode;
export declare function schemaToOpenAPI(input: SchemaInput, context?: SchemaConversionContext): Record<string, unknown>;
export declare function schemaToJSONSchema(input: SchemaInput, context?: SchemaConversionContext): Record<string, unknown>;
export declare function generateOpenAPI(app: Nelysia<any, any, any>, options?: OpenAPIOptions): {
    openapi: string;
    info: {
        title: string;
        version: string;
    };
    paths: Record<string, Record<string, unknown>>;
    components?: {
        schemas: Record<string, unknown>;
    } | undefined;
};
export declare function openapi(options?: OpenAPIOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function openapiUi(options?: OpenAPIUiOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function swaggerUi(options?: SwaggerUiOptions): (app: Nelysia<any, any, any>) => Nelysia<any, any, any>;
export declare function generateClientTypes(app: Nelysia<any, any, any>): string;
export {};
//# sourceMappingURL=index.d.ts.map