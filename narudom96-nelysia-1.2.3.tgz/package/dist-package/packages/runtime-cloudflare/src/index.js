import { createFetchHandler } from "../../runtime-fetch/src/server.js";
export function createCloudflareHandler(app) {
    const handler = createFetchHandler(app);
    return (request, env, executionContext) => handler(request, { env, executionContext });
}
export function createCloudflareWorker(app) {
    return { fetch: createCloudflareHandler(app) };
}
//# sourceMappingURL=index.js.map