import type { Nelysia } from "../../core/src/app.ts";
export declare function createCloudflareHandler(app: Nelysia<any, any, any>): (request: Request, env?: unknown, executionContext?: unknown) => Promise<Response>;
export declare function createCloudflareWorker(app: Nelysia<any, any, any>): {
    fetch: (request: Request, env?: unknown, executionContext?: unknown) => Promise<Response>;
};
//# sourceMappingURL=index.d.ts.map