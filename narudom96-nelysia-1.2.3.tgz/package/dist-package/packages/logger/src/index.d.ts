import type { Logger, NelysiaPlugin } from "../../core/src/index.ts";
export type LogLevel = "debug" | "info" | "warn" | "error";
export interface LogEntry {
    level: LogLevel;
    message: string;
    fields?: Record<string, unknown>;
    timestamp: string;
}
export interface LoggerOptions {
    level?: LogLevel;
    format?: "auto" | "pretty" | "json";
    colors?: boolean;
    startup?: boolean;
    routes?: boolean;
    requests?: boolean;
    errors?: boolean;
    sink?: (entry: LogEntry) => void | Promise<void>;
    redact?: (key: string, value: unknown) => unknown;
}
export type LoggerPlugin = NelysiaPlugin<{
    logger: Logger;
}>;
export declare function logger(options?: LoggerOptions): LoggerPlugin;
export type { Logger };
//# sourceMappingURL=index.d.ts.map